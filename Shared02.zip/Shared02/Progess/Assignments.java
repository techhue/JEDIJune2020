
https://github.com/techhue/JEDIJune2020


DAY 01
__________________________________________________________________

	Reading and Practice Assignment
	______________________________________________________________
		Reference Book
			Linux Pocket Guide, Orielly Publication
				Pages 11 To 29
				Pages 37 to 70

DAY 02
__________________________________________________________________
	Reading and Practice Assignment
	______________________________________________________________
		Reference Book
			Linux Pocket Guide, Orielly Publication
				Pages 71 to 95
				Pages 104 to 114


DAY 03
__________________________________________________________________
	Reading and Practice Assignment
	______________________________________________________________
		GIT Reference Notes
			GP.01.GettingStarted.pdf
			GP.02.GitBasics.pdf
			GP.03.GitBranching.pdf
			GP.05.DistributedGit.pdf
			GP.08.CustomizingGit.pdf
			SuccessfulGitBranchingModel.pdf
	

