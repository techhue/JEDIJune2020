
https://github.com/techhue/JEDIJune2020


DAY 01
__________________________________________________________________

	Reading and Practice Assignment
	______________________________________________________________
		Reference Book
			Linux Pocket Guide, Orielly Publication
				Pages 11 To 29
				Pages 37 to 70

DAY 02
__________________________________________________________________
	Reading and Practice Assignment
	______________________________________________________________
		Reference Book
			Linux Pocket Guide, Orielly Publication
				Pages 71 to 95
				Pages 104 to 114


DAY 03
__________________________________________________________________
	Reading and Practice Assignment
	______________________________________________________________
		GIT Reference Notes
			GP.01.GettingStarted.pdf
			GP.02.GitBasics.pdf
			GP.03.GitBranching.pdf
			GP.05.DistributedGit.pdf
			GP.08.CustomizingGit.pdf

			SuccessfulGitBranchingModel.pdf

DAY 04
__________________________________________________________________
	Coding And Practice Examples
	______________________________________________________________
		Till Today Code Examples Practice and Study

	Coding Assignments
	______________________________________________________________
		Write Program In C To Calculate Factorial of Any Large N.
			Without Using Any Libraries.

	Reading Assignments
	______________________________________________________________
		Reference Book : Java Complete Reference, 8th Edition
		Read Following Chapters
			1. Data Types, Variables and Arrays
			2. Operators
			3. Control Statements

	Exploration Assignments
	______________________________________________________________
		What is The Definition of Modulus Operator in Mathematics?
		Compare Working of Modulus Operator in C, C++ and Java with Mathematical Definition


DAY 04 : In Class WorK
__________________________________________________________________
	In Class Assignment
	______________________________________________________________

	// Write Following Sum Function In C
		// It should RETURN Valid SUM [ As Per Mathematics Rules ]
		// or Otherwise Print Can't Calculate Sum For Given x and y

	int sum( int x, int y ) {

	}

	// Copy Your Code In Discussion Sheet

	In Class Assignment
	______________________________________________________________
	Is Java int Type Leads to Underflow/Overlow 
		Yes/No
		Design Mitigration Strategy

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		RAISE YOUR HAND: IF YOU COMPLETED ABOVE ASSIGNMENSTS
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



