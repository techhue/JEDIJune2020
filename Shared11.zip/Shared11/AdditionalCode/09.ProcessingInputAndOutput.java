
//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch09.sec01;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class StreamDemo {
    public static void main(String[] args) throws IOException {
        Path path = Paths.get("alice.txt");
        try (InputStream in = Files.newInputStream(path)) {
            int firstByte = in.read();
            System.out.println("First byte: " + firstByte);
            byte[] moreBytes = new byte[1_000_000];
            int bytesRead = in.read(moreBytes);
            System.out.println("Bytes read: " + bytesRead);            
        }
        
        byte[] allBytes = Files.readAllBytes(path);
        String contents = new String(allBytes, StandardCharsets.UTF_8);
        System.out.println(contents.substring(0, 50) + "...");

        byte[] helloBytes = { 72, 101, 108, 108, 111, 10 };
        path = Paths.get("test.txt");
        try (OutputStream out = Files.newOutputStream(path)) {
            out.write(helloBytes);
        }
        
        URL url = new URL("http://horstmann.com/index.html");
        try (InputStream in = url.openStream()) {
            Files.copy(in, Paths.get("index.html"), StandardCopyOption.REPLACE_EXISTING);
        }
        
        InputStream in = new ByteArrayInputStream(helloBytes);
        int n;
        do {
            n = in.read();
            System.out.println(n);
        } while (n != -1); 

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(helloBytes);    
        byte[] bytes = out.toByteArray();
        System.out.println(new String(bytes, StandardCharsets.UTF_8));
    }
}

//_______________________________________________________________________________________

package ch09.sec01;

import java.io.DataInput;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

// See http://en.wikipedia.org/wiki/BMP_file_format

public class BinaryIO {
    public static void main(String[] args) throws IOException {
        Path path = Paths.get("chart.bmp");
        try (InputStream inStream = Files.newInputStream(path)) {            
            DataInput in = new DataInputStream(inStream);
            byte[] header = new byte[2];
            in.readFully(header);
            int size = swap(in.readInt());
            in.readInt();
            in.readInt();
            int headerSize = swap(in.readInt());
            int width = swap(in.readInt());
            int height = swap(in.readInt());
            short planes = swap(in.readShort());
            short depth = swap(in.readShort());
            int compressionMode = swap(in.readInt());;
            System.out.println("Header: " + new String(header, StandardCharsets.US_ASCII));
            System.out.println("Size: " + size);
            System.out.println("Header size : " + headerSize);
            System.out.println("Width : " + width);
            System.out.println("Height : " + height);
            System.out.println("Planes : " + planes);
            System.out.println("Depth : " + depth);
            System.out.println("Compression mode : " + compressionMode);
        }
    }
    
    public static int swap(int n) {
        return (n & 0xFF000000) >> 24 | (n & 0xFF0000) >> 8 | (n & 0xFF00) << 8 | (n & 0xFF) << 24; 
    }

    public static short swap(short n) {
        return (short) ((n & 0xFF00) >> 8 | (n & 0xFF) << 8); 
    }
    
}

//_______________________________________________________________________________________

package ch09.sec01;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class CharsetDemo {
    public static void main(String[] args) {
        System.out.println("Default charset on this computer: " + Charset.defaultCharset());
        System.out.println("Available charsets on this JVM: " + Charset.availableCharsets().keySet());
        
        String str = "Java\u2122";
        System.out.println(str);
        byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        showBytes(bytes);
            // Note that the trademark character takes three bytes
        showBytes(str.getBytes(StandardCharsets.UTF_16));
            // Note the byte order mark
        showBytes(str.getBytes(StandardCharsets.ISO_8859_1));
            // The trademark character can't be encoded and becomes a ?
        
        System.out.println(new String(bytes, Charset.forName("windows-1252")));
            // How can you tell this was the wrong encoding? How could a program tell?
    }
    
    public static void showBytes(byte[] bytes) {
        for (byte b : bytes) System.out.printf("%2X ", b);
        System.out.println();
    }
}

//_______________________________________________________________________________________

package ch09.sec01;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

public class TextIO {
    public static void main(String[] args) throws IOException {
        Path path = Paths.get("alice.txt");
        String content = Files.readString(path);
        System.out.println("Characters: " + content.length());
        List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
        System.out.println("Lines: " + lines.size());
        try (Stream<String> lineStream = Files.lines(path, StandardCharsets.UTF_8)) {
            System.out.println("Average line length: " + lineStream.mapToInt(String::length).average().orElse(0));
        }
        try (Scanner in = new Scanner(path, "UTF-8")) {
            in.useDelimiter("\\PL+");
            int words = 0;
            while (in.hasNext()) {
                in.next();
                words++;
            }
            System.out.println("Words: " + words);
        }
        
        
        URL url = new URL("http://horstmann.com/index.html");
        try (BufferedReader reader
                = new BufferedReader(new InputStreamReader(url.openStream()))) {
            Stream<String> lineStream = reader.lines();
            System.out.println("Average line length: " + lineStream.mapToInt(String::length).average().orElse(0));
        }
        
        path = Paths.get("hello.txt");
        try (PrintWriter out = new PrintWriter(Files.newBufferedWriter(path, StandardCharsets.UTF_8))) {
            out.println("Hello");
        }
        content = "World\n";
        Files.write(path, content.getBytes(StandardCharsets.UTF_8), StandardOpenOption.APPEND);
        path = Paths.get("copyOfAlice.txt");
        Files.write(path, lines, StandardCharsets.UTF_8);
        
        StringWriter writer = new StringWriter();
        Throwable throwable = new IllegalStateException();
        throwable.printStackTrace(new PrintWriter(writer));
        String stackTrace = writer.toString();
        System.out.println("Stack trace: " + stackTrace);
    }
}

//_______________________________________________________________________________________

package ch09.sec01;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

// See http://en.wikipedia.org/wiki/BMP_file_format

public class MemoryMappedFileDemo {
    public static void main(String[] args) throws IOException {
        Path path = Paths.get("chart.bmp");
        try (FileChannel channel = FileChannel.open(path,
                StandardOpenOption.READ, StandardOpenOption.WRITE)) {
            ByteBuffer buffer = channel.map(FileChannel.MapMode.READ_WRITE,
                    0, channel.size());
            buffer.order(ByteOrder.LITTLE_ENDIAN);
            int size = buffer.getInt(2);
            int headerSize = buffer.getInt(14);
            int width = buffer.getInt(18);
            int height = buffer.getInt(22);
            short planes = buffer.getShort(26);
            short depth = buffer.getShort(28);
            int compressionMode = buffer.getInt(30);;
            System.out.println("Size: " + size);
            System.out.println("Header size : " + headerSize);
            System.out.println("Width : " + width);
            System.out.println("Height : " + height);
            System.out.println("Planes : " + planes);
            System.out.println("Depth : " + depth);
            System.out.println("Compression mode : " + compressionMode);
            
        }
    }
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch09.sec02;

import java.nio.file.Path;
import java.nio.file.Paths;

public class PathDemo {
    public static void main(String[] args) {
        Path absolute = Paths.get("/", "home", "cay");
        Path relative = Paths.get("myprog", "conf", "user.properties");
        System.out.println(absolute);
        System.out.println(relative);
        Path homeDirectory = Paths.get("/home/cay");
        System.out.println(homeDirectory);
        
        Path workPath = homeDirectory.resolve("myprog/work");
        System.out.println(workPath);
        Path tempPath = workPath.resolveSibling("temp");
        System.out.println(tempPath);
        
        relative = Paths.get("/home/cay").relativize(Paths.get("/home/fred/myprog"));
        System.out.println(relative);
        
        Path normalized = Paths.get("/home/cay/../fred/./myprog").normalize();
        System.out.println("normalized: " + normalized);
        
        absolute = Paths.get("config").toAbsolutePath();
        System.out.println("absolute: " + absolute);
        
        Path p = Paths.get("/home", "cay", "myprog.properties");
        System.out.println("p: " + p);
        Path parent = p.getParent(); 
        System.out.println("parent of p: " + parent);
        Path file = p.getFileName(); 
        System.out.println("file of p: " + file);
        Path root = p.getRoot(); 
        System.out.println("root of p: " + root);
        Path first = p.getName(0);
        System.out.println("first of p: " + first);
        Path dir = p.subpath(0, p.getNameCount() - 1);
        System.out.println("dir of p: " + dir);
        
        System.out.println("Components of p");
        for (Path component : p) {
            System.out.println(component);
        }
    }
}

//_______________________________________________________________________________________

package ch09.sec02;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public class FileDemo {
    public static void main(String[] args) throws IOException {
        Path tempPath = Files.createTempDirectory("corejava");

        Path workDir = Files.createDirectory(tempPath.resolve("work"));
        System.out.println(workDir);
        Path tempFile = Files.createTempFile(workDir, "test", ".txt");
        System.out.println(tempFile);
        Files.write(tempFile, "Hello".getBytes(StandardCharsets.UTF_8));
        Files.copy(tempFile, workDir.resolve("hello.txt"));

        Path target2 = workDir.resolve("hello2.txt");
        Files.move(tempFile, target2, StandardCopyOption.ATOMIC_MOVE);
        boolean deleted = Files.deleteIfExists(target2);
        if (deleted) System.out.println("Deleted " + target2);
    }
}

//_______________________________________________________________________________________

package ch09.sec02;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.util.stream.Stream;

public class DirectoryDemo {
    public static void main(String[] args) throws IOException {
        Path path = Paths.get(System.getProperty("java.home"));
        System.out.printf("Directories inside %s:\n", path);
        try (Stream<Path> entries = Files.list(path)) {
            entries.forEach(System.out::println);
        }
        
        System.out.printf("\nDirectories and subdirectories inside %s:\n", path);
        try (Stream<Path> entries = Files.walk(path)) {
            System.out.printf("%d files\n", entries.count());
        }
        
        // Copy directory tree
        
        Path source = path;
        Path target = Files.createTempDirectory("corejava").resolve("jre");
        Files.walk(source).forEach(p -> {
            try {
                Path q = target.resolve(source.relativize(p));
                if (Files.isDirectory(p)) {
                    System.out.printf("Creating %s\n", q);
                    Files.createDirectory(q);
                }
                else {
                    System.out.printf("Copying %s to %s\n", p, q);
                    Files.copy(p, q);
                }
            } catch (IOException ex) {
                throw new UncheckedIOException(ex);
            }
        });
        
        // Delete the copy
                
        Path root = target;
        Files.walkFileTree(root, new SimpleFileVisitor<Path>() {
            public FileVisitResult visitFile(Path file,
                    BasicFileAttributes attrs) throws IOException {
                Files.delete(file);
                System.out.printf("Deleting %s\n", file);                
                return FileVisitResult.CONTINUE;
            }
            public FileVisitResult postVisitDirectory(Path dir,
                    IOException ex) throws IOException {
                if (ex != null) throw ex;
                Files.delete(dir);
                System.out.printf("Removing %s\n", dir);
                return FileVisitResult.CONTINUE;
            }
        });        
    }
}
//_______________________________________________________________________________________

package ch09.sec02;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.stream.Stream;

public class ZipDemo {
    public static void main(String[] args) throws IOException, URISyntaxException {
        Path javaHome = Paths.get(System.getProperty("java.home"));
        Path zipFile = javaHome.getParent().resolve("src.zip");
        if (!Files.exists(zipFile)) {
            System.err.println(zipFile + " does not exist.");
            return;
        }

        String sourceName = "java/lang/String.java";
        Path tempDir = Files.createTempDirectory("corejava");
        Path targetPath = tempDir.resolve(sourceName);
        Files.createDirectories(targetPath.getParent());
        try (FileSystem zipfs = FileSystems.newFileSystem(zipFile, null)) {
            Files.copy(zipfs.getPath(sourceName), targetPath);
            Files.lines(targetPath).limit(40).forEach(System.out::println);
            System.out.println("\nFiles that don't end in .java:");
            try (Stream<Path> entries = Files.walk(zipfs.getPath("/"))) {
                entries.filter(p -> Files.isRegularFile(p) && !p.toString().endsWith(".java"))
                    .forEach(System.out::println);
            }            
        }

        Path zipPath = tempDir.resolve("myfile.zip");
        URI uri = new URI("jar", zipPath.toUri().toString(), null);
        // Constructs the URI jar:file://myfile.zip
        try (FileSystem zipfs = FileSystems.newFileSystem(uri,
                Collections.singletonMap("create", "true"))) {
            // To add files, copy them into the ZIP file system
            Path filePath = targetPath;            
            Files.copy(filePath, zipfs.getPath("/").resolve("String.java"));
        }
        System.out.println("Made zip file at " + zipPath);
    }
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch09.sec03;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import jdk.incubator.http.*;

public class HttpClientDemo {
    public static void main(String[] args) throws URISyntaxException, IOException, InterruptedException {
        System.out.println("GET demo");
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI("http://horstmann.com"))
                .GET()
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandler.asString());
        System.out.println(response.body());
        
        System.out.println("\n\n\nPOST demo");        
        client = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.ALWAYS)
                .build();        
        Map<String, String> postData = new HashMap<>();        
        postData.put("repo", "bj4cc");
        postData.put("problem", "ch06/c06_exp_6_105");
        postData.put("level", "1");
        postData.put("Numbers.java", solution);
        boolean first = true;
        StringBuilder body = new StringBuilder();
        for (Map.Entry<String, String> entry : postData.entrySet()) {
            if (first) first = false;
            else body.append("&");
            body.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            body.append("=");
            body.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }
        
        request = HttpRequest.newBuilder()
                .uri(new URI("http://codecheck.it/check"))
                .header("Accept-Charset", "UTF-8")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyProcessor.fromString(body.toString()))
                .build();
        response = client.send(request, HttpResponse.BodyHandler.asString());
        System.out.println(response.body());
   }
    
    public static String solution = "public class Numbers {\n" + 
            "    public int countSevens(int n) {\n" + 
            "        int r = 0;\n" + 
            "        while (n > 0) {\n" + 
            "            if (n % 10 == 7) r++;\n" + 
            "            n /= 10;\n" + 
            "        }\n" + 
            "        return r;\n" +
            "    }" +
            "}";    
}

//_______________________________________________________________________________________

package ch09.sec03;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PostDemo {
    public static void main(String[] args) throws IOException {
        URL url = new URL("http://codecheck.it/check");
        URLConnection connection = url.openConnection();
        connection.setRequestProperty("Accept-Charset", "UTF-8");
        connection.setDoOutput(true);
        try (Writer out = new OutputStreamWriter(
                connection.getOutputStream(), "UTF-8")) {
            Map<String, String> postData = new HashMap<>();
            
            postData.put("repo", "bj4cc");
            postData.put("problem", "ch06/c06_exp_6_105");
            postData.put("level", "1");
            postData.put("Numbers.java", solution);
            boolean first = true;
            for (Map.Entry<String, String> entry : postData.entrySet()) {
                if (first) first = false;
                else out.write("&");
                out.write(URLEncoder.encode(entry.getKey(), "UTF-8"));
                out.write("=");
                out.write(URLEncoder.encode(entry.getValue(), "UTF-8"));
            }
        }
        
        Map<String, List<String>> headers = connection.getHeaderFields();
        System.out.println("Response headers: " + headers);
        try (InputStream in = connection.getInputStream()) {
            String contents = new String(readAllBytes(in));
            System.out.println(contents);
        }
    }
    
    public static byte[] readAllBytes(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        copy(in, out);
        return out.toByteArray();
    }

    public static void copy(InputStream in, OutputStream out) throws IOException {
        final int BLOCKSIZE = 1024;
        byte[] bytes = new byte[BLOCKSIZE];
        int len;
        while ((len = in.read(bytes)) != -1) out.write(bytes, 0, len);
        in.close();
        out.close();
    }
    
    public static String solution = "public class Numbers {\n" + 
            "    public int countSevens(int n) {\n" + 
            "        int r = 0;\n" + 
            "        while (n > 0) {\n" + 
            "            if (n % 10 == 7) r++;\n" + 
            "            n /= 10;\n" + 
            "        }\n" + 
            "        return r;\n" +
            "    }" +
            "}";
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch09.sec04;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexDemo {
    public static void main(String[] args) {
        System.out.printf("%-30s%-30s%-20s\n", "Regex", "Input", "Matches");
        showMatches("a", "Java");
        showMatches(".", "Java");
        showMatches("\\x{1D546}", "The octonions \uD835\uDD46");
        showMatches("\\uD835\\uDD46", "The octonions \uD835\uDD46");
        showMatches("\\n", "Hello\nWorld");
        showMatches("\\cJ", "Hello\nWorld");
        showMatches("\\\\", "c:\\windows\\system");
        showMatches("\\Q.\\E", "Hello. World.");
        showMatches("[A-Za-z]", "San Jos\u00E9");
        showMatches("[^aeiou]", "Hello");
        showMatches("[\\p{L}&&[^A-Za-z]]", "San Jos\u00E9");
        showMatches("\\d", "99 bottles of beer");
        showMatches("\\w", "99 bottles of rosé");
        showMatches("\\s*,\\s*", "Hello, World");
        showMatches("(e|o).l", "Hello, World");
        showMatches("(['\"]).*\\1", "Hello, 'World'");
        showMatches("(?<quote>['\"]).*\\k<quote>", "Hello, 'World'");
        showMatches("(?:[a-z]:)?([\\\\/])\\w+(\\1\\w+)*", "c:\\windows\\system and /bin");
        showMatches("(?i:jpe?g)", "JPEG, jpeg, JPG, and jpg");
        showMatches("[0-9]{3,}", "99 bottles of 333");
        showMatches("<(.+?>).*</\\1", "<i>Hello</i>, <b>World</b>!");
        showMatches("'[^']*+'", "This 'joke' isn't funny.");
        showMatches("\\G\\w+,\\s*", "Athens, Rome, New York, Paris");
        showMatches("\\p{Punct}", "Hello, World!");
        showMatches("\\p{sc=Greek}", "2\u03C0r");
        showMatches("\\p{InLetterlike Symbols}", "Java\u2122");
        showMatches("\\pP", "Hello, World!"); // Ok to omit {} around one-letter properties
        showMatches("\\p{IsUppercase}", "Hello, World!");
        showMatches("\\p{javaJavaIdentifierStart}", "99 bottles");
    }
    
    public static void showMatches(String regex, String input) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        System.out.printf("%-30s%-30s", regex, input);
        while (matcher.find()) {
            String match = matcher.group();
            System.out.print(match + " ");
        }
        System.out.println();        
    }
}

//_______________________________________________________________________________________

package ch09.sec04;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FindingOneOrAllMatches {
    public static void main(String[] args) {
        String regex = "[+-]?\\d+";
        CharSequence input = "-123";
        if (Pattern.matches(regex, input)) 
            System.out.println(input + " is an integer");
        
        
        Pattern pattern = Pattern.compile(regex);
        input = "Fred";
        Matcher matcher = pattern.matcher(input);
        if (!matcher.matches())  
            System.out.println(input + " is not an integer");
        
        Stream<String> strings = Stream.of("99 bottles of beer on the wall, 99 bottles of beer.".split(" "));
        Stream<String> result = strings.filter(pattern.asPredicate());
        System.out.println(result.collect(Collectors.toList()));
        
        input = "June 14, 1903";
        matcher = pattern.matcher(input);
        while (matcher.find()) {
            String match = matcher.group();            
            System.out.println(match);        
        }
    }
}

//_______________________________________________________________________________________

package ch09.sec04;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Groups {
    public static void main(String[] args) {
        Pattern pattern = Pattern.compile("(\\p{Alnum}+(\\s+\\p{Alnum}+)*)\\s+([A-Z]{3})([0-9.]*)");
        String input = "Blackwell Toaster    USD29.95";
        Matcher matcher = pattern.matcher(input);
        if (matcher.matches()) {
            String item = matcher.group(1);
            String currency = matcher.group(3);
            String price = matcher.group(4);
            System.out.printf("item=%s,currency=%s,price=%s\n", item, currency, price);
        }
        
        pattern = Pattern.compile("(\\p{Alnum}+(?:\\s+\\p{Alnum}+)*)\\s+([A-Z]{3})([0-9.]*)");
        matcher = pattern.matcher(input);
        if (matcher.matches()) {
            String item = matcher.group(1);
            String currency = matcher.group(2);
            String price = matcher.group(3);
            System.out.printf("item=%s,currency=%s,price=%s\n", item, currency, price);
        }
        
        pattern = Pattern.compile("(?<item>\\p{Alnum}+(\\s+\\p{Alnum}+)*)\\s+(?<currency>[A-Z]{3})(?<price>[0-9.]*)");
        matcher = pattern.matcher(input);
        if (matcher.matches()) {
            String item = matcher.group("item");
            String currency = matcher.group("currency");
            String price = matcher.group("price");
            System.out.printf("item=%s,currency=%s,price=%s\n", item, currency, price);
        }        
    }
}

//_______________________________________________________________________________________

package ch09.sec04;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class RemovingOrReplacingMatches {
    public static void main(String[] args) {
        Pattern commas = Pattern.compile("\\s*,\\s*");
        CharSequence input = "Peter , Paul,  Mary";
        String[] tokens = commas.split(input);
        System.out.println(Arrays.toString(tokens));
        
        Stream<String> tokenStream = commas.splitAsStream(input);
        System.out.println(tokenStream.collect(Collectors.toList()));
        
        Matcher matcher = commas.matcher(input);
        String result = matcher.replaceAll(",");
        System.out.println(result);
        
        Pattern time = Pattern.compile("(\\d{1,2}):(\\d{2})");
        matcher = time.matcher("3:45");
        result = matcher.replaceAll("$1 hours and $2 minutes");
        System.out.println(result);
        
        result = "3:45".replaceAll(
                "(?<hours>\\d{1,2}):(?<minutes>\\d{2})", 
                "${hours} hours and ${minutes} minutes");
        System.out.println(result);        
    }
}

//_______________________________________________________________________________________

package ch09.sec04;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Flags {
    public static void main(String[] args) {
        showMatches("[AO\u00C9]", Pattern.CASE_INSENSITIVE, "San José");
        showMatches("[AO\u00C9]", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CHARACTER_CLASS, "San José");
        showMatches("^[a-z ]+$", Pattern.MULTILINE, "99 bottles\nof beer\non the\rwall\n");
        showMatches("^[a-z ]+$", Pattern.MULTILINE | Pattern.UNIX_LINES, "99 bottles\nof beer\non the\rwall\n");
        showMatches(".", 0, "99 bottles\nof beer");
        showMatches(".", Pattern.DOTALL, "99 bottles\nof beer");
        showMatches(".# What a pattern!", Pattern.COMMENTS, "Hello");
        showMatches(".", Pattern.LITERAL, "Hello. World.");
        showMatches("\u00E9", 0, "San Jose\u0301");
        showMatches("\u00E9", Pattern.CANON_EQ, "San Jose\u0301");
    }
    
    public static void showMatches(String regex, int flags, String input) {
        Pattern pattern = Pattern.compile(regex, flags);
        Matcher matcher = pattern.matcher(input);
        System.out.printf("%-30s%-30s", regex, input);
        while (matcher.find()) {
            String match = matcher.group();
            System.out.print(match + " ");
        }
        System.out.println();        
    }
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch09.sec05;

import java.io.Serializable;

public class Employee implements Serializable {
    private String name;
    private double salary;
    private Manager boss;
        
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public void setBoss(Manager boss) {
        this.boss = boss;
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
    
    public String toString() {
        return String.format("%s[name=%s,salary=%.2f,boss=%s]", 
                getClass().getName(), name, salary, boss);
    }
}

//_______________________________________________________________________________________

package ch09.sec05;

public class Manager extends Employee {
    private double bonus;
    
    public Manager(String name, double salary) {
        super(name, salary);
        bonus = 0;
    }
    
    public void setBonus(double bonus) {
        this.bonus = bonus;
    }
    
    public double getSalary() { // Overrides superclass method
        return super.getSalary() + bonus;
    }
    
    public String toString() {
        return super.toString() + "[bonus=" + bonus + "]";
    }
} 
//_______________________________________________________________________________________

package ch09.sec05;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javafx.geometry.Point2D;

public class SerializationDemo {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Path path = Paths.get("employees.ser");
        try (ObjectOutputStream out = new ObjectOutputStream(
                Files.newOutputStream(path))) {
            Employee peter = new Employee("Fred", 90000);
            Employee paul = new Manager("Barney", 105000);
            Manager mary = new Manager("Mary", 180000);
            peter.setBoss(mary);
            paul.setBoss(mary);
            out.writeObject(peter);
            out.writeObject(paul);
            
            out.writeObject(new LabeledPoint("origin", new Point2D(0, 0)));
            
            out.writeObject(PersonDatabase.INSTANCE.findById(1));
        }
        try (ObjectInputStream in = new ObjectInputStream(
                Files.newInputStream(path))) {
            Employee e1 = (Employee) in.readObject();
            Employee e2 = (Employee) in.readObject();
            System.out.println(e1);
            System.out.println(e2);
            
            System.out.println(in.readObject());
            System.out.println(in.readObject());
        }
    }
}

//_______________________________________________________________________________________

package ch09.sec05;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import javafx.geometry.Point2D;

public class LabeledPoint implements Serializable {
    private String label;
    private transient Point2D point;
    
    public LabeledPoint(String label, Point2D point) {
        this.label = label;
        this.point = point;
    }
    
    public String toString() {
        // TODO Auto-generated method stub
        return String.format("%s[label=%s,point=%s]", getClass().getName(), label, point);
    }
    
    private void writeObject(ObjectOutputStream out) throws IOException {
        out.defaultWriteObject();
        out.writeDouble(point.getX());
        out.writeDouble(point.getY());
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        double x = in.readDouble();
        double y = in.readDouble();
        point = new Point2D(x, y);
    }    
}

//_______________________________________________________________________________________

package ch09.sec05;

import java.io.Serializable;

public class Person implements Serializable {
    private int id;
    private String name;

    public Person(int id, String name) {
        this.id = id;
        this.name = name;
    }
    
    public int getId() {
        return id;
    }
    
    private Object writeReplace() {
        return new PersonProxy(id);
    }
    
    public String toString() {
        return String.format("%s[id=%d,name=%s]", getClass().getName(), id, name);
    }
}
//_______________________________________________________________________________________

package ch09.sec05;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public enum PersonDatabase {
    INSTANCE;
    
    private Map<Integer, Person> people = new ConcurrentHashMap<>(); 
    private PersonDatabase() {
        add(new Person(1, "Adam"));
        add(new Person(2, "Eve"));
    }
    
    public Person findById(int id) { return people.get(id); }
    
    public void add(Person p) {
        people.putIfAbsent(p.getId(), p);
    }
}
//_______________________________________________________________________________________

package ch09.sec05;

import java.io.Serializable;

public class PersonProxy implements Serializable {
    private int id;

    public PersonProxy(int id) {
        this.id = id;
    }

    public Object readResolve() {
        return PersonDatabase.INSTANCE.findById(id);
    }
}