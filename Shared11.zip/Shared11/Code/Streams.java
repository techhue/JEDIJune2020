package learnJava;

/*
javac -version
javac Streams.java -d ClassFiles
java -cp ClassFiles learnJava.Streams
*/

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Arrays;
import java.util.stream.*;
import java.math.BigInteger;
import java.nio.file.Path;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.nio.file.Files;
import java.util.ArrayList;


class StreamDemo {
    private static int previous; 

    public static void workingWithoutStreams() {
    	// Read file into string
    	String contents = "";
    	try {
			contents = new String(Files.readAllBytes(Paths.get("alice.txt"))); 
		} catch( IOException io) {}

		List<String> words = Arrays.asList(contents.split("\\PL+"));
		int count = 0;
		for (String w : words) {
		   if (w.length() > 5) count++;
		}
		System.out.println("Words Counts : " + count);
    }

    public static void workingWithStreams()  {
    	// Read file into string
    	String contents = "";
    	try {
			contents = new String(Files.readAllBytes( Paths.get("alice.txt")));
		} catch( IOException io) {}
		
		List<String> words = Arrays.asList(contents.split("\\PL+"));

		long count = words.stream()
		       .filter(w -> w.length() > 5) // Filter Every W where W.length > 5
		       .count();
		System.out.println("Words Counts : " + count);
	}

	public static void workingWithoutStreams1() {
		Integer[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		Stream<Integer> numbersStream = Stream.of(numbers);
		Integer[] squares;
		squares = numbersStream.filter( number -> number % 2 == 0 ) 
						.map( number -> number * number ) 
		       			.toArray(Integer[]::new);
		
		for ( Integer number: squares) {
			System.out.println(number);
		}
	}
	   
	public static void workingWithoutStreams2() {
        Stream<Integer> values = Stream.of(1, 2, 2, 3, 3, 3, 4, 2);
        values = values.filter( x -> { 
							            boolean r = previous != x; 
							            previous = x; 
							            return r; } );
//						.peek(x -> { return; });
        values.forEach(System.out::println);

        // forEach( Lamdba ) {
        // 	for value in values:
        // 		Lamdba(value)
        // }
    }
}

// import java.io.IOException;
// import java.math.BigInteger;
// import java.nio.file.Files;
// import java.nio.file.Path;
// import java.nio.file.Paths;
// import java.util.List;
// import java.util.regex.Pattern;
// import java.util.stream.Collectors;
// import java.util.stream.Stream;

class CreatingStreams {
    public static <T> void show(String title, Stream<T> stream) {
        final int SIZE = 10;
        List<T> firstElements = stream.limit(SIZE + 1).collect(Collectors.toList());
        System.out.print(title + ": ");
        if (firstElements.size() <= SIZE)
            System.out.println(firstElements);
        else {
            firstElements.remove(SIZE);
            String out = firstElements.toString();
            System.out.println(out.substring(0, out.length() - 1) + ", ...]");
        }
    }

    public static void workingWithCreatingStreams() throws IOException {
        // Path path = Paths.get("alice.txt");
        // String contents = Files.readString(path);
    	String contents = "";
    	try {
			contents = new String(Files.readAllBytes( Paths.get("alice.txt")));
		} catch( IOException io) {}

        Stream<String> words = Stream.of(contents.split("\\PL+"));
        show("words", words);
        Stream<String> song = Stream.of("gently", "down", "the", "stream");
        show("song", song);
        Stream<String> silence = Stream.empty();
        show("silence", silence);

        Stream<String> echos = Stream.generate(() -> "Echo");
        show("echos", echos);

        Stream<Double> randoms = Stream.generate(Math::random);
        show("randoms", randoms);

        Stream<BigInteger> integers = Stream.iterate(BigInteger.ONE, n -> n.add(BigInteger.ONE));
        show("integers", integers);

        BigInteger limit = new BigInteger("7");
        // integers = Stream.iterate(BigInteger.ZERO,
        //     					n -> n.compareTo(limit) < 0,
        //     					n -> n.add(BigInteger.ONE));
        // show("integers", integers);
        
        Stream<String> wordsAnotherWay = Pattern.compile("\\PL+").splitAsStream(contents);
        show("wordsAnotherWay", wordsAnotherWay);

        // try (Stream<String> lines = Files.lines(path)) {
        //     show("lines", lines);
        // }
    }
}

// import java.io.IOException;
// import java.nio.file.Files;
// import java.nio.file.Paths;
// import java.util.ArrayList;
// import java.util.List;
// import java.util.stream.Collectors;
// import java.util.stream.Stream;

class FilterMapDemo {
    public static <T> void show(String title, Stream<T> stream) {
        final int SIZE = 10;
        List<T> firstElements = stream.limit(SIZE + 1).collect(Collectors.toList());
        System.out.print(title + ": ");
        if (firstElements.size() <= SIZE)
            System.out.println(firstElements);
        else {
            firstElements.remove(SIZE);
            String out = firstElements.toString();
            System.out.println(out.substring(0, out.length() - 1) + ", ...]");
        }
    }

    public static Stream<String> codePoints(String s) {
        List<String> result = new ArrayList<>();
        int i = 0;
        while (i < s.length()) {
            int j = s.offsetByCodePoints(i, 1);
            result.add(s.substring(i, j));
            i = j;
        }
        return result.stream();
    }

    public static void workingWithFilterMapDemo() throws IOException {
        // String contents = Files.readString(Paths.get("alice.txt"));
    	String contents = "";
    	try {
			contents = new String(Files.readAllBytes( Paths.get("alice.txt")));
		} catch( IOException io) {}

        // List<String> words = List.of(contents.split("\\PL+"));
		List<String> words = Arrays.asList(contents.split("\\PL+"));

        Stream<String> longWords = words.stream().filter(w -> w.length() > 12);
        show("longWords", longWords);

        Stream<String> lowercaseWords = words.stream().map(String::toLowerCase);
        show("lowercaseWords", lowercaseWords);

        String[] song = { "row", "row", "row", "your", "boat", "gently", "down",
                "the", "stream" };
        Stream<String> firstChars = Stream.of(song).filter(w -> w.length() > 0).map(s -> s.substring(0, 1));
        show("firstChars", firstChars);

        Stream<String> letters = Stream.of(song).flatMap(w -> codePoints(w));
        show("letters", letters);
    }
}

// import java.io.IOException;
// import java.util.ArrayList;
// import java.util.List;
// import java.util.stream.Collectors;
// import java.util.stream.Stream;

class ExtractingCombining {
    public static <T> void show(String title, Stream<T> stream) {
        final int SIZE = 10;
        List<T> firstElements = stream.limit(SIZE + 1).collect(Collectors.toList());
        System.out.print(title + ": ");
        if (firstElements.size() <= SIZE)
            System.out.println(firstElements);
        else {
            firstElements.remove(SIZE);
            String out = firstElements.toString();
            System.out.println(out.substring(0, out.length() - 1) + ", ...]");
        }
    }

    public static Stream<String> codePoints(String s) {
        List<String> result = new ArrayList<>();
        int i = 0;
        while (i < s.length()) {
            int j = s.offsetByCodePoints(i, 1);
            result.add(s.substring(i, j));
            i = j;
        }
        return result.stream();
    }

    public static void workingWithExtractingCombining() throws IOException {
        Stream<Double> randoms = Stream.generate(Math::random).limit(5);
        show("randoms", randoms);

        String contents = "   Hello, World!   ";
        Stream<String> words = Stream.of(contents.split("\\PL+")).skip(1);
        show("words", words);
        
        String str = "123 Main Street";
        Stream<String> initialDigits = codePoints(str).takeWhile(
                s -> "0123456789".contains(s));
        show("initialDigits", initialDigits);
        str = "   Hello   ";
        Stream<String> withoutInitialWhiteSpace = codePoints(str).dropWhile(
                s -> s.trim().length() == 0);
        show("withoutInitialWhiteSpace", withoutInitialWhiteSpace);

        Stream<String> combined = Stream.concat(codePoints("Hello"),
                codePoints("Cat\uD83D\uDE3B"));
        show("combined", combined);
    }
}

public class Streams {
	public static void playWithStreams() {
		StreamDemo.workingWithoutStreams();
		StreamDemo.workingWithStreams();
		StreamDemo.workingWithoutStreams1();
		StreamDemo.workingWithoutStreams2();
	}

	public static void playWithCreatingStreams() {
		try { CreatingStreams.workingWithCreatingStreams(); }
		catch(IOException io){}
	}

	public static void playWithFilterMapDemo() {
		try { FilterMapDemo.workingWithFilterMapDemo(); }
		catch(IOException io){}
	}
	
	public static void playWithExtractingCombining() {
		try { ExtractingCombining.workingWithExtractingCombining(); }
		catch(IOException io){}
	}

	public static void main(String[] args) {
		System.out.println("\nFunction : playWithStreams");
		playWithStreams();

		System.out.println("\nFunction : playWithCreatingStreams");
		playWithCreatingStreams();

		System.out.println("\nFunction : playWithFilterMapDemo");
		playWithFilterMapDemo();
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");	
	}
}
