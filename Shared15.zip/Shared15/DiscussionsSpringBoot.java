
// HelloWorld.java
package hello;
 public class HelloWorld {
   public static void main(String[] args) {
   Greeter greeter = new Greeter();
   System.out.println(greeter.sayHello());
   }
}

// Greeter.java
package hello;
public class Greeter {
   public String sayHello() {
   return "Hello world!";
   }
}
// build.gradle
apply plugin: 'application'
apply plugin: 'java'
mainClassName = 'hello.HelloWorld'

// WORKING WITH JAVA GRADLE PROJECT
// ______________________________________________________________________________________
//  brew install gradle
//  gradle -version
//  gradle tasks

//  mkdir JavaGradleProject; cd JavaGradleProject;
//  mkdir -p src/main/java/hello
//  vim HelloWorld.java
//  vim Greeter.java
//  vim build.gradle
//  gradle build
//  vim build.gradle 
//  gradle run 

IntelligeneMachine:JavaGradleProject intelligene$ tree
.
├── build.gradle
└── src
    └── main
        └── java
            └── hello
                ├── Greeter.java
                └── HelloWorld.java


____________________________________________________________________
// HelloWorld.java
package hello;
import org.joda.time.LocalTime;

public class HelloWorld {
   public static void main(String[] args) {
    LocalTime currentTime = new LocalTime();
    System.out.println("The Current Local Time: " + currentTime);

   Greeter greeter = new Greeter();
   System.out.println(greeter.sayHello());
   }
}

___________________________________
// build.gradle

apply plugin: 'application'
apply plugin: 'java'

mainClassName = 'hello.HelloWorld'

repositories {
    mavenCentral()
}

sourceCompatibility = 1.8
targetCompatibility = 1.8

dependencies {
    compile "joda-time:joda-time:2.2"
    testCompile "junit:junit:4.12"
}

jar {
	baseName = 'JavaGradleLearning'
	version = '0.0.1'
}
____________________________________________________________________

The repositories block indicates that the build should resolve its dependencies from
the Maven Central repository. Gradle leans heavily on many conventions and facilities
established by the Maven build tool, including the option of using Maven Central as a
source of library dependencies.

With the dependencies block, you declare a single dependency for Joda Time. Specifically, you’re asking for (reading right to left) version 2.2 of the joda-time library, in the joda-time group.

Another thing to note about this dependency is that it is a compile dependency, indicating that it should be available during compile-time (and if you were building a WAR file, included in the /WEB-INF/libs folder of the WAR). Other notable types of dependencies include:

    providedCompile. 
      Required dependencies for compiling the project code, but that will be provided at runtime by a container running the code (for example, the Java Servlet API).

    testCompile. 
      Dependencies used for compiling and running tests, but not required for building or running the project’s runtime code.

____________________________________________________________________
	JAR File Is Actually a Zip File Containing Java Byte Code(.class files)
	unzip JavaGradleLearning.jar

	Following Command Install Gradle Wrapper and Gradle Build Tool As Part of Project
	gradle wrapper --gradle-version 3.10

The Gradle Wrapper is the preferred way of starting a Gradle build. It consists of a batch script for Windows and a shell script for OS X and Linux. These scripts allow you to run a Gradle build without requiring that Gradle be installed on your system. This used to be something added to your build file, but it’s been folded into Gradle, so there is no longer any need. Instead, you simply use the following command.

The Gradle Wrapper is now available for building your project. Add it to your version control system, and everyone that clones your project can build it just the same. It can be used in the exact same way as an installed version of Gradle. Run the wrapper script to perform the build task, just like you did previously:

	./gradlew build

The first time you run the wrapper for a specified version of Gradle, it downloads and caches the Gradle binaries for that version. The Gradle Wrapper files are designed to be committed to source control so that anyone can build the project without having to first install and configure a specific version of Gradle.


______________________________________________________________________________________
2.3.2. Installing the Spring Boot CLI
______________________________________________________________________________________

The Spring Boot CLI (Command Line Interface) is a command line tool that you can use to quickly prototype with Spring. It lets you run Groovy scripts, which means that you have a familiar Java-like syntax without so much boilerplate code.

You do not need to use the CLI to work with Spring Boot, but it is definitely the quickest way to get a Spring application off the ground.

Manual Installation
You can download the Spring CLI distribution from the Spring software repository:

spring-boot-cli-2.3.1.RELEASE-bin.zip

spring-boot-cli-2.3.1.RELEASE-bin.tar.gz

Cutting edge snapshot distributions are also available.

Once downloaded, follow the INSTALL.txt instructions from the unpacked archive. In summary, there is a spring script (spring.bat for Windows) in a bin/ directory in the .zip file. Alternatively, you can use java -jar with the .jar file (the script helps you to be sure that the classpath is set correctly).


Installation with SDKMAN!
____________________________________________________________________

SDKMAN! (The Software Development Kit Manager) can be used for managing multiple versions of various binary SDKs, including Groovy and the Spring Boot CLI. Get SDKMAN! from sdkman.io and install Spring Boot by using the following commands:

$ sdk install springboot
$ spring --version
Spring Boot v2.3.1.RELEASE

If you develop features for the CLI and want easy access to the version you built, use the following commands:

$ sdk install springboot dev /path/to/spring-boot/spring-boot-cli/target/spring-boot-cli-2.3.1.RELEASE-bin/spring-2.3.1.RELEASE/
$ sdk default springboot dev
$ spring --version

Spring CLI v2.3.1.RELEASE

The preceding instructions install a local instance of spring called the dev instance. It points at your target build location, so every time you rebuild Spring Boot, spring is up-to-date.

You can see it by running the following command:

$ sdk ls springboot

================================================================================
Available Springboot Versions
================================================================================
> + dev
* 2.3.1.RELEASE

================================================================================
+ - local version
* - installed
> - currently in use
================================================================================


OSX Homebrew Installation
____________________________________________________________________
If you are on a Mac and use Homebrew, you can install the Spring Boot CLI by using the following commands:

$ brew tap pivotal/tap
$ brew install springboot

Homebrew installs spring to /usr/local/bin.

If you do not see the formula, your installation of brew might be out-of-date. In that case, run brew update and try again.
MacPorts Installation
If you are on a Mac and use MacPorts, you can install the Spring Boot CLI by using the following command:

$ sudo port install spring-boot-cli
Command-line Completion

The Spring Boot CLI includes scripts that provide command completion for the BASH and zsh shells. You can source the script (also named spring) in any shell or put it in your personal or system-wide bash completion initialization. On a Debian system, the system-wide scripts are in /shell-completion/bash and all scripts in that directory are executed when a new shell starts. For example, to run the script manually if you have installed by using SDKMAN!, use the following commands:

$ . ~/.sdkman/candidates/springboot/current/shell-completion/bash/spring
$ spring <HIT TAB HERE>
  grab  help  jar  run  test  version
If you install the Spring Boot CLI by using Homebrew or MacPorts, the command-line completion scripts are automatically registered with your shell.


Windows Scoop Installation
____________________________________________________________________
If you are on a Windows and use Scoop, you can install the Spring Boot CLI by using the following commands:

> scoop bucket add extras
> scoop install springboot
Scoop installs spring to ~/scoop/apps/springboot/current/bin.

______________________________________________________________________________________

Building an Application with Spring Boot

______________________________________________________________________________________

Will build a simple web application with Spring Boot and add some useful services to it.

What You Need
	A favorite text editor or IDE
	JDK 1.8 or later
	Gradle 4+ or Maven 3.2+

	You can also import the code straight into your IDE:
		Spring Tool Suite (STS)
		IntelliJ IDEA


Creating Spring Boot Application
______________________________________________________________________________________
	Create Initial Spring Boot Project
		Spring initializer
		https://start.spring.io/
	
	Build Initial Project
		./gradlew build
	
	Run Initial Project
		./gradlew bootRun

	Test Initial Project
		curl http://localhost:8080


	// build.gradle
	plugins {
		// Spring Boot Plugin in Gradle
		id 'org.springframework.boot' version '2.3.1.RELEASE'
		id 'io.spring.dependency-management' version '1.0.9.RELEASE'
		// Install Java Plugin in Gradle
		id 'java'
	}

	group = 'com.example'
	version = '0.0.1-SNAPSHOT'
	sourceCompatibility = '1.8'
	// springboot-0.0.1-SNAPSHOT.jar This Is Generated .jar file

	repositories {
		mavenCentral()
	}

	dependencies {
		implementation 'org.springframework.boot:spring-boot-starter-web'
		testImplementation('org.springframework.boot:spring-boot-starter-test') {
			exclude group: 'org.junit.vintage', module: 'junit-vintage-engine'
		}
	}

	test {
		useJUnitPlatform()
	}

	Create File : With Following Code
		src/main/java/com/example/springboot/HelloController.java
		
		package com.example.springboot;

		import org.springframework.web.bind.annotation.RestController;
		import org.springframework.web.bind.annotation.RequestMapping;

		@RestController
		public class HelloController {

			@RequestMapping("/")
			public String index() {
				return "Greetings from Spring Boot!";
			}

		}

	The class is flagged as a @RestController, 
		Meaning it is ready for use by Spring MVC to handle web requests. 
		@RequestMapping maps / to the index() method. 
			When invoked from a browser or by using curl on the command line, the method returns pure text. 
		
		That is because @RestController combines @Controller and @ResponseBody, two annotations that results in web requests returning data rather than a view.


	Modify File : src/main/java/com/example/springboot/SpringbootApplication.java
		package com.example.springboot;

		import java.util.Arrays;
		import org.springframework.boot.CommandLineRunner;
		import org.springframework.boot.SpringApplication;
		import org.springframework.boot.autoconfigure.SpringBootApplication;
		import org.springframework.context.ApplicationContext;
		import org.springframework.context.annotation.Bean;

		@SpringBootApplication
		public class SpringbootApplication {

			public static void main(String[] args) {
				SpringApplication.run(SpringbootApplication.class, args);
			}

			@Bean
			public CommandLineRunner commandLineRunner(ApplicationContext ctx) {
				return args -> {

					System.out.println("Let's inspect the beans provided by Spring Boot:");

					String[] beanNames = ctx.getBeanDefinitionNames();
					Arrays.sort(beanNames);
					for (String beanName : beanNames) {
						System.out.println(beanName);
					}

				};
			}
		}


	@SpringBootApplication is a convenience annotation that adds all of the following:

		@Configuration: Tags the class as a source of bean definitions for the application context.

	@EnableAutoConfiguration: Tells Spring Boot to start adding beans based on classpath settings, other beans, and various property settings. For example, if spring-webmvc is on the classpath, this annotation flags the application as a web application and activates key behaviors, such as setting up a DispatcherServlet.

	@ComponentScan: Tells Spring to look for other components, configurations, and services in the com/example package, letting it find the controllers.


____________________________________________________________________
Spring Bean
____________________________________________________________________
Bean Definition
	Here's a definition of beans in the Spring Framework documentation:

	In Spring, the objects that form the backbone of your application and that are managed by the Spring IoC container are called beans. A bean is an object that is instantiated, assembled, and otherwise managed by a Spring IoC container.


	This class needs a collaborator of type Address:

		public class Address {
		    private String street;
		    private int number;
		 
		    public Address(String street, int number) {
		        this.street = street;
		        this.number = number;
		    }
		 
		    // getters and setters
		}

	Assume we have a class declaration:

		public class Company {
		    private Address address;

		    // Tight Coupling: Should Avoid It!
		    // public Company(String street, int number) {
		    //     this.address = new Address();
		    //     this.address.street = street;
		    //     this.address.number = number;
		    // }

			// Injecting Dependencies		 
		    public Company(Address address) {
		        this.address = address;
		    }
		 
		    // getter, setter and other properties
		}

	Address address = new Address("High Street", 1000);
	Company company = new Company(address);

There's nothing wrong with this approach, but wouldn't it be nice to manage the dependencies in a better way?

Imagine an application with dozens or even hundreds of classes. 

	Sometimes we want to share a single instance of a class across the whole application, 
	Other times we need a separate object for each use case, and so on.

Managing such a number of objects is nothing short of a nightmare. 
	This is where Inversion of Control comes to the rescue.

	____________________________________________________________________

	First off, let's decorate the Company class with the @Component annotation:

	@Component
	public class Company {
	    // this body is the same as before
	}

	Here's a configuration class supplying bean metadata to an IoC container:

	@Configuration
	@ComponentScan(basePackageClasses = Company.class)
	public class Config {
	    @Bean
	    public Address getAddress() {
	        return new Address("High Street", 1000);
	    }
	}

	The configuration class produces a bean of type Address. It also carries the @ComponentScan annotation, which instructs the container to looks for beans in the package containing the Company class.

	When a Spring IoC container constructs objects of those types, all the objects are called Spring beans as they are managed by the IoC container.


Since we defined beans in a configuration class, we'll need an instance of the AnnotationConfigApplicationContext class to build up a container:

	ApplicationContext context = new AnnotationConfigApplicationContext(Config.class);

A quick test verifies the existence as well as property values of our beans:

	Company company = context.getBean("company", Company.class);
	assertEquals("High Street", company.getAddress().getStreet());
	assertEquals(1000, company.getAddress().getNumber());


The result proves that the IoC container has created and initialized beans correctly.

____________________________________________________________________


	Build Modified Project
		./gradlew build
	
	Run Modified Project
		./gradlew bootRun

	Test Modified Project
		curl http://localhost:8080

____________________________________________________________________


There is also a CommandLineRunner method marked as a @Bean, and this runs on start up. 
It retrieves all the beans that were created by your application or that were automatically added by Spring Boot. It sorts them and prints them out.

MockMvc comes from Spring Test and lets you, through a set of convenient builder classes, send HTTP requests into the DispatcherServlet and make assertions about the result. 


Note the use of @AutoConfigureMockMvc and @SpringBootTest to inject a MockMvc instance. Having used @SpringBootTest, we are asking for the whole application context to be created. An alternative would be to ask Spring Boot to create only the web layers of the context by using @WebMvcTest. In either case, Spring Boot automatically tries to locate the main application class of your application, but you can override it or narrow it down if you want to build something different.

As well as mocking the HTTP request cycle, you can also use Spring Boot to write a simple full-stack integration test.

 For example, instead of (or as well as) the mock test shown earlier, we could create the following test (from src/test/java/com/example/springboot/HelloControllerIT.java):


you are building a web site for your business, you probably need to add some management services. Spring Boot provides several such services (such as health, audits, beans, and more) with its actuator module.


____________________________________________________________________

You can create your web service.
Begin the process by thinking about service interactions.

The service will handle GET requests for /greeting, 
	Optionally with a name parameter in the query string. 

	The GET request should return a 200 OK response with JSON in the body that represents a greeting. 

	It should resemble the following output:

{
    "id": 1,
    "content": "Hello, World!"
}





