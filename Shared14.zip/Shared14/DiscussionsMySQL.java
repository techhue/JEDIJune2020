
How Many Done Formal Course On...
_____________________________________________
	Database Fundamental Concepts
	Database Management System

What is a File?
_____________________________________________
	One Dimentional Stream
	In Unix/Linux Everything is File...


Database Management Systems
_____________________________________________
	Primary Key
		One or more columns that can be used as a unique identifier for each row in a table.
	Foreign Key
		One or more columns that can be used together to identify a single row in another table.

	Composite Keys

	Entity
	Column 	: Atribute
	Row 	: Record/Tuples
	Table 	: Set Of Records/Tuples 

	Result Set : Set Of Records/Tuples Meeting A Criteria

	
_____________________________________________
Along with Codd’s definition of the relational model, he proposed a language called DSL/Alpha for manipulating the data in relational tables. Shortly after Codd’s paper was released, IBM commissioned a group to build a prototype based on Codd’s ideas.

	This group created a simplified version of DSL/Alpha that they called SQUARE. Refinements to SQUARE led to a language called SEQUEL, which was, finally, shortened to SQL.


_SQL schema statements_, which are used to define the data structures stored in the database; 

_SQL data statements_, which are used to manipulate the data structures previously defined using SQL schema statements;

_SQL transaction statements_, which are used to begin, end, and roll back transactions

		CREATE TABLE corporation
		 (corp\_id SMALLINT,
		  name VARCHAR(30),
		  CONSTRAINT pk\_corporation PRIMARY KEY (corp\_id)
		 );

	This statement creates a table with two columns, `corp_id` and `name`, with the `corp_id` column identified as the primary key for the table. 

Inserts a row into the `corporation` table for Acme Paper Corporation:

	INSERT INTO corporation (corp\_id, name)
	VALUES (27, 'Acme Paper Corporation');

	This statement adds a row to the `corporation` table with a value of `27` for the `corp_id` column and a value of `Acme Paper Corporation` for the `name` column.

		mysql< SELECT name
	    -> FROM corporation
	    -> WHERE corp_id = 27;

	All database elements created via SQL schema statements are stored in a special set of tables called the data dictionary. This “data about the database” is known collectively as metadata

	Just like tables that you create yourself, data dictionary tables can be queried via a select statement, thereby allowing you to discover the current data structures deployed in the database at runtime


The data portion of the SQL language, which consists of the `select`, `update`, `insert`, and `delete` commands


	SELECT t.txn_id, t.txn_type_cd, t.txn_date, t.amount
	FROM individual i
	  INNER JOIN account a ON i.cust_id = a.cust_id
	  INNER JOIN product p ON p.product_cd = a.product_cd
	  INNER JOIN transaction t ON t.account_id = a.account_id
	WHERE i.fname = 'George' AND i.lname = 'Blake'
	  AND p.name = 'checking account';


	The previous queries contain three different _clauses_: `select`, `from`, and `where`. 

	Almost every query that you encounter will include at least these three clauses, although there are several more that can be used for more specialized purposes.

	The role of each of these three clauses is demonstrated by the following:

		SELECT \* one or more things */ ...
		FROM \* one or more places */ ...
		WHERE \* one or more conditions apply */ ...

	Most SQL implementations treat any text between the `/*` and `*/` tags as comments.


		SELECT cust_id, fname
		FROM individual
		WHERE lname = 'Smith';

		
		This query searches the `individual` table for all rows whose `lname` column matches the string `'Smith'` and returns the `cust_id` and `fname` columns from those rows.


You will receive feedback from the database engine as to how many rows were affected by your statement. If you are using an interactive tool such as the `mysql` command-line tool mentioned earlier, then you will receive feedback concerning how many rows were either:

		*   Returned by your `select` statement
		*   Created by your `insert` statement
		*   Modified by your `update` statement
		*   Removed by your `delete` statement

	
	In general, it’s a good idea to check this info to make sure your statement didn’t do something unexpected.

	 	(like when you forget to put a `where` clause on your `delete` statement and delete every row in the table!).


What Is MySQL?
==============

Relational databases have been available commercially for more than three decades. Some of the most mature and popular commercial products include:

		*   Oracle Database from Oracle Corporation    
		*   SQL Server from Microsoft
		*   DB2 Universal Database from IBM
    

	For example, a report may need to bring together data stored in Oracle, Hadoop, JSON files, CSV files, and Unix log files. A new generation of tools have been built to meet this type of challenge, and one of the most promising is Apache Drill, which is an open source query engine that allows users to write queries that can access data stored in most any database or filesystem.


MySQL Data Types
================

	In general, all the popular database servers have the capacity to store the same types of data, such as strings, dates, and numbers. 

	Where they typically differ is in the specialty data types, such as XML and JSON documents or spatial data. Since this is an introductory book on SQL and since 98% of the columns you encounter will be simple data types, we covers only the character, date (a.k.a. temporal), and numeric data types.


Character Data
--------------
	Character data can be stored as either fixed-length or variable-length strings; 

		The difference is that fixed-length strings are right-padded with spaces and always consume the same number of bytes, and variable-length strings are not right-padded with spaces and don’t always consume the same number of bytes. 

		When defining a character column, you must specify the maximum size of any string to be stored in the column.

			char(20)    /* fixed-length */
			varchar(20) /* variable-length */

		The maximum length for `char` columns is currently 255 bytes, whereas `varchar` columns can be up to 65,535 bytes. If you need to store longer strings (such as emails, XML documents, etc.), then you will want to use one of the text types (`mediumtext` and `longtext`). 

		In general, you should use the `char` type when all strings to be stored in the column are of the same length, such as state abbreviations, and the `varchar` type when strings to be stored in the column are of varying lengths. Both `char` and `varchar` are used in a similar fashion in all the major database servers.


### Character sets

	For languages that use the Latin alphabet, such as English, there is a sufficiently small number of characters such that only a single byte is needed to store each character. 

	Other languages, such as Japanese and Korean, contain large numbers of characters, thus requiring multiple bytes of storage for each character. Such character sets are therefore called _multibyte character sets_.


		MySQL can store data using various character sets, both single-byte and multibyte. To view the supported character sets in your server, you can use the `show` command


		When defining a column, simply name one of the supported character sets after the type definition, as in:

			city_name varchar(20) character set latin1


		With MySQL, you may also set the default character set for your entire database:

			create database european_sales character set latin1;

		
### Text data
	If you need to store data that might exceed the 64 KB limit for `varchar` columns, you will need to use one of the text types


			Table 2-1. MySQL text types

	_____________________________________________
	Text type 		| 	Maximum number of bytes
	_____________________________________________
	`tinytext`		| 	255
	`text`			| 	65,535
	`mediumtext`	|	16,777,215
	`longtext`		| 	4,294,967,295
	_____________________________________________


	When choosing to use one of the text types, you should be aware of the following:

	*   If the data being loaded into a text column exceeds the maximum size for that type, the data will be truncated.
	    
	*   Trailing spaces will not be removed when data is loaded into the column.
	    
	*   When using `text` columns for sorting or grouping, only the first 1,024 bytes are used, although this limit may be increased if necessary.
	    
	*   The different text types are unique to MySQL. SQL Server has a single `text` type for large character data, whereas DB2 and Oracle use a data type called `clob`, for Character Large Object.
	    
	*   Now that MySQL allows up to 65,535 bytes for `varchar` columns (it was limited to 255 bytes in version 4), there isn’t any particular need to use the `tinytext` or `text` type.
   	
		If you are creating a column for free-form data entry, such as a `notes` column to hold data about customer interactions with your company’s customer service department, then `varchar` will probably be adequate. If you are storing documents, however, you should choose either the `mediumtext` or `longtext` type.


Numeric Data
------------

Scenarios

	A column indicating whether a customer order has been shipped
		This type of column, referred to as a _Boolean_, would contain a `0` to indicate `false` and a `1` to indicate `true`.

	A system-generated primary key for a transaction table
		This data would generally start at `1` and increase in increments of one up to a potentially very large number.

	An item number for a customer’s electronic shopping basket
		The values for this type of column would be positive whole numbers between 1 and, perhaps, 200 (for shopaholics).

	Positional data for a circuit board drill machine
		High-precision scientific or manufacturing data often requires accuracy to eight decimal points.


Numeric types are those used to store whole numbers, or _integers_. When specifying one of these types, you may also specify that the data is _unsigned_, which tells the server that all data stored in the column will be greater than or equal to zero.


					Table 2-2. MySQL integer types
_______________________________________________________________________
Type 		|	Signed range 					|	Unsigned range
_______________________________________________________________________
`tinyint`	|	−128 to 127	 					|	0 to 255
`smallint`	| −32,768 to 32,767					|	0 to 65,535
`mediumint`	| −8,388,608 to 8,388,607			| 	0 to 16,777,215
`int`		| −2,147,483,648 to 2,147,483,647 	| 	0 to 4,294,967,295
`bigint`	| −2^63 to 2^63 - 1					| 	0 to 2^64 - 1
_______________________________________________________________________


	When you create a column using one of the integer types, MySQL will allocate an appropriate amount of space to store the data, which ranges from one byte for a `tinyint` to eight bytes for a `bigint`. Therefore, you should try to choose a type that will be large enough to hold the biggest number you can envision being stored in the column without needlessly wasting storage space.


				Table 2-3. MySQL floating-point types
_______________________________________________________________________
types 				| 			Numeric range
_______________________________________________________________________
float(p, s)			|	−3.402823466E+38 to −1.175494351E-38
					|	and 1.175494351E-38 to 3.402823466E+38

double(p, s)		| 	−1.7976931348623157E+308 to −2.2250738585072014E-308
					| and 2.2250738585072014E-308 to 1.7976931348623157E+308
_______________________________________________________________________

	When using a floating-point type, you can specify a _precision_ (the total number of allowable digits both to the left and to the right of the decimal point) and a _scale_ (the number of allowable digits to the right of the decimal point), but they are not required

		If you specify a precision and scale for your floating-point column, remember that the data stored in the column will be rounded if the number of digits exceeds the scale and/or precision of the column. 

		For example, a column defined as `float(4,2)` will store a total of four digits, two to the left of the decimal and two to the right of the decimal. Therefore, such a column would handle the numbers 27.44 and 8.19 just fine, but the number 17.8675 would be rounded to 17.87


Temporal Data
-------------
	Dates and/or times. This type of data is referred to as _temporal_ data

					Table 2-4. MySQL temporal types
_______________________________________________________________________
Type 			| 	Default format 		| 			Allowable values
_______________________________________________________________________
`date`			| YYYY-MM-DD			| `1000-01-01` 
				|						|  to `9999-12-31`
`datetime`		| YYYY-MM-DD HH:MI:SS 	| `1000-01-01 00:00:00.000000`
				|						|  to `9999-12-31 23:59:59.999999`
`timestamp`		| YYYY-MM-DD HH:MI:SS 	| `1970-01-01 00:00:00.000000`
				|						|  to `2038-01-18 22:14:07.999999`
`year`			| YYYY 					| `1901` to `2155`
`time` 			| HHH:MI:SS 			| `−838:59:59.000000`
				|						|  to `838:59:59.000000`
_______________________________________________________________________


	The `datetime`, `timestamp`, and `time` types also allow fractional seconds of up to 6 decimal places (microseconds). When defining columns using one of these data types, you may supply a value from 0 to 6; for example, specifying `datetime(2)` would allow your time values to include hundredths of a second.


Temporal types would be used to implement the examples shown earlier:

*   Columns to hold the expected future shipping date of a customer order and an employee’s birth date would use the `date` type, since it is unrealistic to schedule a future shipment down to the second and unnecessary to know at what time a person was born.
    
*   A column to hold information about when a customer order was actually shipped would use the `datetime` type, since it is important to track not only the date that the shipment occurred but the time as well.
    
*   A column that tracks when a user last modified a particular row in a table would use the `timestamp` type. The `timestamp` type holds the same information as the `datetime` type (year, month, day, hour, minute, second), but a `timestamp` column will automatically be populated with the current date/time by the MySQL server when a row is added to a table or when a row is later modified.
    
*   A column holding just year data would use the `year` type.
    
*   Columns that hold data regarding the length of time needed to complete a task would use the `time` type. For this type of data, it would be unnecessary and confusing to store a date component, since you are interested only in the number of hours/minutes/seconds needed to complete the task. This information could be derived using two `datetime` columns (one for the task start date/time and the other for the task completion date/time) and subtracting one from the other, but it is simpler to use a single `time` column.


Table Creation
==============

	Types of information that describe a person:

	*   Name    
	*   Eye color
	*   Birth date
	*   Address
	*   Favorite foods

_______________________________________________________________________
Column 				| 	Type 			| Allowable values
_______________________________________________________________________
`name` 				| `varchar(40)`		|
`eye_color` 		| `char(2)`			| `BL`, `BR`, `GR`
`birth_date`		|					|
`date`				|					|
`address` 			| `varchar(100)`	|
`favorite_foods` 	| `varchar(200)`	|
_______________________________________________________________________



	CREATE TABLE person
	 (person_id SMALLINT UNSIGNED,
	  fname VARCHAR(20),
	  lname VARCHAR(20),
	  eye_color CHAR(2),
	  birth_date DATE,
	  street VARCHAR(30),
	  city VARCHAR(20),
	  state VARCHAR(20),
	  country VARCHAR(20),
	  postal_code VARCHAR(20),
	  CONSTRAINT pk_person PRIMARY KEY (person_id)
	 );


	eye_color CHAR(2) CHECK (eye_color IN ('BR','BL','GR'))	
	eye_color ENUM('BR','BL','GR'),


	CREATE TABLE person
	 (person_id SMALLINT UNSIGNED,
	  fname VARCHAR(20),
	  lname VARCHAR(20),
	  eye_color ENUM('BR','BL','GR'),
	  birth_date DATE,
	  street VARCHAR(30),
	  city VARCHAR(20),
	  state VARCHAR(20),
	  country VARCHAR(20),
	  postal_code VARCHAR(20),
	  CONSTRAINT pk_person PRIMARY KEY (person_id)
	 );


______________________________________________
##### What Is Null?
______________________________________________
	In some cases, it is not possible or applicable to provide a value for a particular column in your table. 

	For example, when adding data about a new customer order, the `ship_date` column cannot yet be determined. In this case, the column is said to be _null_ (note that I do not say that it _equals_ null), which indicates the absence of a value. 

	Null is used for various cases where a value cannot be supplied, such as:

		*   Not applicable
		*   Unknown
		*   Empty set


	CREATE TABLE favorite_food
    (person_id SMALLINT UNSIGNED,
    food VARCHAR(20),
    CONSTRAINT pk_favorite_food PRIMARY KEY (person_id, food),
    CONSTRAINT fk_fav_food_person_id FOREIGN KEY (person_id)
    REFERENCES person (person_id)
    );


*   Since a person can have more than one favorite food (which is the reason this table was created in the first place), it takes more than just the `person_id` column to guarantee uniqueness in the table. This table, therefore, has a two-column primary key: `person_id` and `food`.
    
*   The `favorite_food` table contains another type of constraint which is called a _foreign key constraint_. This constrains the values of the `person_id` column in the `favorite_food` table to include _only_ values found in the `person` table. With this constraint in place, I will not be able to add a row to the `favorite_food` table indicating that `person_id 27` likes pizza if there isn’t already a row in the `person` table having a `person_id` of `27`.



Inserting Data
--------------

There are three main components to an `insert` statement:

	*   The name of the table into which to add the data
	*   The names of the columns in the table to be populated
	*   The values with which to populate the columns
    
	You are not required to provide data for every column in the table
		Unless all the columns in the table have been defined as `not null`

### Generating numeric key data

	Before inserting data into the `person` table, it would be useful to discuss how values are generated for numeric primary keys. Other than picking a number out of thin air, you have a couple of options:

	*   Look at the largest value currently in the table and add one.
	*   Let the database server provide the value for you.

	In the case of MySQL, however, you simply need to turn on the _auto-increment_ feature for your primary key column
    

    ALTER TABLE person MODIFY person_id SMALLINT UNSIGNED AUTO_INCREMENT;


	INSERT INTO person
	(person_id, fname, lname, eye_color, birth_date)
	VALUES (null, 'William','Turner', 'BR', '1972-05-27');

	SELECT * FROM person;

	SELECT person_id, fname, lname, birth_date
    FROM person
    WHERE lname = 'Singh';

	CREATE TABLE favorite_food
    (person_id SMALLINT UNSIGNED,
    food VARCHAR(20),
    CONSTRAINT pk_favorite_food PRIMARY KEY (person_id, food),
    CONSTRAINT fk_fav_food_person_id FOREIGN KEY (person_id)
    REFERENCES person (person_id)
    );

    INSERT INTO favorite_food (person_id, food)
    VALUES (1, 'Pizza');

    INSERT INTO favorite_food (person_id, food)
    VALUES (1, 'Chiken');

    INSERT INTO favorite_food (person_id, food)
    VALUES (1, 'Mutton');

    INSERT INTO favorite_food (person_id, food)
    VALUES (2, 'Horses');

    INSERT INTO favorite_food (person_id, food)
    VALUES (2, 'Thakur');

	SELECT food
    FROM favorite_food
    WHERE person_id = 1
    ORDER BY food;

	UPDATE favorite_food
	SET food = 'Paneer'
	WHERE food = 'Thakur';

	UPDATE favorite_food
	SET food = 'Dal Makhni'
	WHERE food = 'Horses';


	UPDATE person
    SET street = '1225 Tremont St.',
    city = 'Boston',
    state = 'MA',
    country = 'USA',
    postal_code = '02138'
    WHERE person_id = 1;

	DELETE FROM person
    WHERE person_id = 3;

	Again, the primary key is being used to isolate the row of interest, so a single row is deleted from the table. Like the `update` statement, more than one row can be deleted depending on the conditions in your `where` clause, and all rows will be deleted if the `where` clause is omitted.
	
	INSERT INTO favorite_food (person_id, food)
    VALUES (999, 'UselessFood');

	In this case, the `favorite_food` table is considered the _child_ and the `person` table is considered the _parent_, since the `favorite_food` table is dependent on the `person` table for some of its data. If you plan to enter data into both tables, you will need to create a row in `parent` before you can enter data into `favorite_food`.
	
	###### Note
	Foreign key constraints are enforced only if your tables are created using the InnoDB storage engine.

Column Value Violations
-----------------------
	UPDATE person
    SET eye_color = 'ZZ'
    WHERE person_id = 1;

Invalid Date Conversions
------------------------
	UPDATE person
    SET birth_date = 'DEC-21-1980'
    WHERE person_id = 1;

    Valid Date Conversions
	------------------------
	UPDATE person
    SET birth_date = str_to_date('DEC-21-1980' , '%b-%d-%Y')
    WHERE person_id = 1;

	
###### Note

	Discussed the various temporal data types
	Date-formatting strings such as `YYYY-MM-DD`. While many database servers use this style of formatting.
	MySQL uses `%Y` to indicate a four-character year. 

	Here are a few more formatters that you might need when converting strings to `datetime`s in MySQL:

	%a The short weekday name, such as Sun, Mon, ...
	%b The short month name, such as Jan, Feb, ...
	%c The numeric month (0..12)
	%d The numeric day of the month (00..31)
	%f The number of microseconds (000000..999999)
	%H The hour of the day, in 24-hour format (00..23)
	%h The hour of the day, in 12-hour format (01..12)
	%i The minutes within the hour (00..59)
	%j The day of year (001..366)
	%M The full month name (January..December)
	%m The numeric month
	%p AM or PM
	%s The number of seconds (00..59)
	%W The full weekday name (Sunday..Saturday)
	%w The numeric day of the week (0=Sunday..6=Saturday)
	%Y The four-digit year

Running Commands On MySQL Database
_______________________________________________________________________

	Connecting To MySQL Database

		mysql -u USERNAME -p 

	Checks Are Performed
		
		Once the server has verified your username and password and issued you a connection, you are ready to execute queries (along with other SQL statements). 

		Each time a query is sent to the server, the server checks the following things prior to statement execution:

		*   Do you have permission to execute the statement?
		*   Do you have permission to access the desired data?
		*   Is your statement syntax correct?


______________________________________________
Sakila Database
______________________________________________
	https://dev.mysql.com/doc/index-other.html

	Download
	https://downloads.mysql.com/docs/sakila-db.zip
	Unzip It 
		In UNZIPPEDPATH
	
	source UNZIPPEDPATH/sakila-schema.sql
	source UNZIPPEDPATH/sakila-data.sql

	use sakila;
	show tables;
		23 Tables


	Table 2-9. Sakila schema definitions
Table Name 		Definition
______________________________________________
`film`			A movie that has been released and can be rented
`actor` 		A person who acts in films
`customer`		A person who watches films
`category`		A genre of films
`payment`		A rental of a film by a customer
`language`		A language spoken by the actors of a film
`film_actor`	An actor in a film
`inventory` 	A film available for rental


_______________________________________________________________________
Running Commands For Sakila Database
_______________________________________________________________________

	SELECT first_name, last_name
	FROM customer
	WHERE last_name = 'ZIEGLER';

	SELECT * FROM category;
	SELECT * FROM language;
	
_______________________________________________________________________
Clause Name |						Purpose
_______________________________________________________________________
`select`	| Determines which columns to include in the query’s result set
`from`		| Identifies the tables from which to retrieve data 
			|	and how the tables should be joined
`where`		| Filters out unwanted data
`group by`	| Used to group rows together by common column values
`having`	| Filters out unwanted groups
`order by`	| Sorts the rows of the final result set by one or more columns
_______________________________________________________________________

	All of the clauses shown in are included in the ANSI specification. 


	SELECT language_id, name, last_update
	FROM language;


SELECT Clause
================
	
	The select clause determines which of all possible columns should be included
in the query’s result set.

	Select clause by including things such as:
		Columns : Comma Seperated List of Column Atributes
		Literals, such as numbers or strings
		Expressions, such as transaction.amount * −1
		Built-in function calls, 
			such as ROUND(transaction.amount, 2) 
		User-defined function calls

	SELECT version(),
    user(),
    database();

	SELECT language_id,
    'COMMON' language_usage, /* Column Aliases */
    language_id * 3.1415927 lang_pi_value,
    upper(name) language_name
    FROM language;

 	SELECT language_id,
	'COMMON' AS language_usage,
	language_id * 3.1415927 AS lang_pi_value,
	upper(name) AS language_name
	FROM language;
	
	// List of Actors(ALL i.e. even Repeated) Which Acted in Films
	SELECT actor_id FROM film_actor ORDER BY actor_id;
	SELECT ALL actor_id FROM film_actor ORDER BY actor_id;
	
	// List of Actors(Distinct) Which Acted in Films
	SELECT DISTINCT actor_id FROM film_actor ORDER BY actor_id;

	However, the all keyword is the default and never needs to be explicitly named, so most programmers do not include all in their queries.


	WARNING!
	_____________________________________________
	Keep in mind that generating a distinct set of results requires the data to be sorted, which can be time consuming for large result sets. Don’t fall into the trap of using distinct just to be sure there are no duplicates; instead, take the time to understand the data you are working with so that you will know whether duplicates are possible.


FROM Clause
================

	The from clause defines the tables used by a query, along with the means of linking the tables together.

	When confronted with the term table, most people think of a set of related rows stored in a database. 

	While this does describe one type of table, I would like to use the word in a more general way by removing any notion of how the data might be stored and concentrating on just the set of related rows. 

	Four different types of tables meet this relaxed definition:

	Permanent tables (i.e., created using the create table statement) 
	Derived tables (i.e., rows returned by a subquery and held in memory) 
	Temporary tables (i.e., volatile data held in memory)
	Virtual tables (i.e., created using the create view statement)


	Each of these table types may be included in a query’s from clause


SUBQUERY

	SELECT concat(cust.last_name, ', ', cust.first_name) full_name
	FROM 
	(SELECT first_name, last_name, email
	FROM customer
	WHERE first_name = 'JESSIE' 
	) cust;

 	Subquery against the customer table returns three columns, and the containing query references two of the three available columns. 

 	The subquery is referenced by the containing query via its alias, which, in this case, is cust. The data in cust is held in memory for the duration of the query and is then discarded.


TEMPORARY TABLE

	Although the implementations differ, every relational database allows the ability to define volatile, or temporary, tables. These tables look just like permanent tables, but any data inserted into a temporary table will disappear at some point (generally at the end of a transaction or when your database session is closed)

	CREATE TEMPORARY TABLE actors_j
	    (actor_id smallint(5),
	    first_name varchar(45),
	    last_name varchar(45)
	    );

	INSERT INTO actors_j
    SELECT actor_id, first_name, last_name
    FROM actor
    WHERE last_name LIKE 'J%';

	SELECT * FROM actors_j;

	These seven rows are held in memory temporarily and will disappear after your session is closed.

	Most database servers also drop the temporary table when the session ends. The exception is Oracle Database, which keeps the definition of the temporary table available for future sessions.

VIEWS

	A view is a query that is stored in the data dictionary. 

	It looks and acts like a table, but there is no data associated with a view (this is why I call it a virtual table). When you issue a query against a view, your query is merged with the view definition to create a final query to be executed.

	CREATE VIEW cust_vw AS
	SELECT customer_id, first_name, last_name, active
	FROM customer;

	SELECT first_name, last_name
    FROM cust_vw
    WHERE active = 0;

    Views are created for various reasons, 
    	Including to hide columns from users and 
    	To simplify complex database designs.

Table Links
	The second deviation from the simple from clause definition is the mandate that if more than one table appears in the from clause, the conditions used to link the tables must be included as well.


	SELECT customer.first_name, customer.last_name,
	time(rental.rental_date) rental_time
	FROM customer
	INNER JOIN rental ON customer.customer_id = rental.customer_id
	WHERE date(rental.rental_date) = '2005-06-14';

Defining Table Aliases

	When multiple tables are joined in a single query, you need a way to identify which table you are referring to when you reference columns in the select, where, group by, having, and order by clauses. You have two choices when referencing a table outside the from clause:
		
		Use the entire table name, such as employee.emp_id.
		Assign each table an alias and use the alias throughout the query.

  	SELECT c.first_name, c.last_name,
  	time(r.rental_date) rental_time
	FROM customer c
	INNER JOIN rental r ON c.customer_id = r.customer_id
	WHERE date(r.rental_date) = '2005-06-14';


	SELECT c.first_name, c.last_name,
	time(r.rental_date) rental_time
	FROM customer AS c
	INNER JOIN rental AS r ON c.customer_id = r.customer_id
	WHERE date(r.rental_date) = '2005-06-14';


WHERE Clause
===============
	The where clause is the mechanism for filtering out unwanted rows from your result set.

		SELECT title
		FROM film
		WHERE rating = 'G' AND rental_duration >= 7;

	This where clause contains two filter conditions, but you can include as many conditions as are required; 
	Individual conditions are separated using operators such as and, or, and not

		SELECT title
		FROM film
		WHERE rating = 'G' OR rental_duration >= 7;

		SELECT title, rating, rental_duration
	    FROM film
	    WHERE (rating = 'G' AND rental_duration >= 7)
	    OR (rating = 'PG-13' AND rental_duration < 4);


GROUBP BY and HAVING Clauses
============================
	Group by clause, which is used to group data by column values

	Write a query that instructs the server to group all rentals by customer, count the number of rentals for each customer, and then return only those customers whose rental count is at least 40.


		SELECT c.first_name, c.last_name, count(*)
	    FROM customer c
	    INNER JOIN rental r ON c.customer_id = r.customer_id
	    GROUP BY c.first_name, c.last_name
	    HAVING count(*) >= 40;

ORDER BY Clause
============================
	The order by clause is the mechanism for sorting your result set using either raw column data or expressions based on column data.

	SELECT c.first_name, c.last_name,
    time(r.rental_date) rental_time
    FROM customer c
    INNER JOIN rental r
    ON c.customer_id = r.customer_id
    WHERE date(r.rental_date) = '2005-06-14';

	SELECT c.first_name, c.last_name,
    time(r.rental_date) rental_time
    FROM customer c
    INNER JOIN rental r
    ON c.customer_id = r.customer_id
    WHERE date(r.rental_date) = '2005-06-14'
	ORDER BY c.last_name asc;

	SELECT c.first_name, c.last_name,
    time(r.rental_date) rental_time
    FROM customer c
    INNER JOIN rental r
    ON c.customer_id = r.customer_id
    WHERE date(r.rental_date) = '2005-06-14'
	ORDER BY c.last_name, c.first_name;

Ascending Versus Descending Sort Order

	SELECT c.first_name, c.last_name,
    time(r.rental_date) rental_time
    FROM customer c
    INNER JOIN rental r
    ON c.customer_id = r.customer_id
    WHERE date(r.rental_date) = '2005-06-14'
	ORDER BY c.last_name desc;

Sorting via Numeric Placeholders

	If you are sorting using the columns in your select clause, you can opt to reference the columns by their position in the select clause rather than by name.

	SELECT c.first_name, c.last_name,
    time(r.rental_date) rental_time
    FROM customer c
    INNER JOIN rental r
    ON c.customer_id = r.customer_id
    WHERE date(r.rental_date) = '2005-06-14'
	ORDER BY 3 desc;


Condition Evaluation
	
	A where clause may contain one or more conditions, separated by the operators and and or. 

	If multiple conditions are separated only by the and operator, then all the conditions must evaluate to true for the row to be included in the result set. 

	Consider the following where clause:
  
  		WHERE first_name = 'STEVEN' AND create_date > '2006-01-01'

	If all conditions in the where clause are separated by the or operator, however, only one of the conditions must evaluate to true for the row to be included in the result set. 

	Consider the following two conditions:

 		WHERE first_name = 'STEVEN' OR create_date > '2006-01-01'

Using Parentheses

	WHERE (first_name = 'STEVEN' OR last_name = 'YOUNG')
  	AND create_date > '2006-01-01'

  	WHERE NOT (first_name = 'STEVEN' OR last_name = 'YOUNG') 
  	AND create_date > '2006-01-01'

	Rewrite the where clause to avoid using the not operator:
	
	WHERE first_name <> 'STEVEN' AND last_name <> 'YOUNG'
  	AND create_date > '2006-01-01'

Building a Condition

	A condition is made up of one or more expressions combined with one or more operators. 

	An expression can be any of the following:
		A number
		A column in a table or view
		A string literal, such as 'Maple Street'
		A built-in function, such as concat('Learning', ' ', 'SQL')
		A subquery
		A list of expressions, such as ('Boston', 'New York', 'Chicago')

	The operators used within conditions include:
		Comparison operators, such as =, !=, <, >, <>, like, in, and between 
		Arithmetic operators, such as +, −, *, and /

Equality Conditions

	amount = 375.25
	film_id = (SELECT film_id FROM film WHERE title = 'RIVER OUTLAW')

	SELECT c.email
    FROM customer c
    INNER JOIN rental r ON c.customer_id = r.customer_id
    WHERE date(r.rental_date) = '2005-06-14';

	SELECT c.email
    FROM customer c
    INNER JOIN rental r ON c.customer_id = r.customer_id
    WHERE date(r.rental_date) <> '2005-06-14';
 
 	DELETE FROM rental
	WHERE year(rental_date) = 2004;

	DELETE FROM rental
	WHERE year(rental_date) <> 2005 AND year(rental_date) <> 2006;

Range Conditions

	SELECT customer_id, rental_date
    FROM rental
    WHERE rental_date < '2005-05-25';

    SELECT customer_id, rental_date
    FROM rental
    WHERE rental_date <= '2005-06-16'
    AND rental_date >= '2005-06-14';

BETWEEN OPERATOR

	When you have both an upper and lower limit for your range, you may choose to use a single condition that utilizes the between operator rather than using two separate conditions

	SELECT customer_id, rental_date
    FROM rental
    WHERE rental_date BETWEEN '2005-06-14' AND '2005-06-16';

	When using the between operator, there are a couple of things to keep in mind. You should always specify the lower limit of the range first (after between) and the upper limit of the range second (after and).

	SELECT customer_id, rental_date
    FROM rental
    WHERE rental_date BETWEEN '2005-06-16' AND '2005-06-14';

	Using between, which is to remember that your upper and lower limits are inclusive, meaning that the values you provide are included in the range limits.

	SELECT customer_id, payment_date, amount
    FROM payment
    WHERE amount BETWEEN 10.0 AND 11.99;

STRING RANGES

	SELECT last_name, first_name
    FROM customer
    WHERE last_name BETWEEN 'FA' AND 'FR';

    To work with string ranges, you need to know the order of the characters within your character set (the order in which the characters within a character set are sorted is called a collation).

Membership Conditions

	SELECT title, rating
    FROM film
    WHERE rating = 'G' OR rating = 'PG';    

    // Can be written as follows with Membership Condition
	
	SELECT title, rating
	FROM film
	WHERE rating IN ('G','PG');


	SELECT title, rating
    FROM film
    WHERE rating IN (SELECT rating FROM film WHERE title LIKE '%PET%');


	SELECT title, rating
	FROM film
	WHERE rating NOT IN ('PG-13','R', 'NC-17');

Matching Conditions

	SELECT last_name, first_name
    FROM customer
    WHERE left(last_name, 1) = 'Q';


USING WILDCARDS

	When searching for partial string matches.

	You might be interested in:
		Strings beginning/ending with a certain character
		Strings beginning/ending with a substring
		Strings containing a certain character anywhere within the string 
		Strings containing a substring anywhere within the string
		Strings with a specific format, regardless of individual characters

	______________________________________________
	Wildcard character 		Matches
	______________________________________________
		_ 					Exactly one character
		% 					Any number of characters (including 0)
	______________________________________________

	SELECT last_name, first_name
    FROM customer
    WHERE last_name LIKE '_A_T%S';

	SELECT last_name, first_name
    FROM customer
    WHERE last_name LIKE 'Q%' OR last_name LIKE 'Y%';

USING REGULAR EXPRESSIONS

	SELECT last_name, first_name
    FROM customer
    WHERE last_name REGEXP '^[QY]';

NULL THOUGHTS!

	Not applicable
		Such as the employee ID column for a transaction that took place at an ATM machine
	Value not yet known
		Such as when the federal ID is not known at the time a customer row is created
	Value undefined
		Such as when an account is created for a product that has not yet been added to the database

	When working with null, you should remember:
		An expression can be null, but it can never equal null.
		Two nulls are never equal to each other.

	To test whether an expression is null, you need to use the is null operator

	SELECT rental_id, customer_id
    FROM rental
    WHERE return_date IS NULL;

	SELECT rental_id, customer_id
    FROM rental
    WHERE return_date = NULL;

    SELECT rental_id, customer_id, return_date
    FROM rental
    WHERE return_date IS NOT NULL;

	SELECT rental_id, customer_id, return_date
    FROM rental
    WHERE return_date IS NULL
    OR return_date NOT BETWEEN '2005-05-01' AND '2005-09-01';


Querying Multiple Tables
	
	What Is a Join?
		Cartesian Product Between Two Tables A and B

	Because the query didn’t specify how the two tables should be joined, the database server generated the Cartesian product, which is every permutation of the two tables.
	
		Permutation of the two tables (599 customers x 603 addresses = 361,197 permutations)

CROSS JOIN

 	SELECT c.first_name, c.last_name, a.address
    FROM customer c JOIN address a;   


INNER JOIN

	To modify the previous query so that only a single row is returned for each customer, you need to describe how the two tables are related. 

	Earlier, I showed that the customer.address_id column serves as the link between the two tables, so this information needs to be added to the on subclause of the from clause:

 	SELECT c.first_name, c.last_name, a.address
    FROM customer c JOIN address a
    ON c.address_id = a.address_id;

		599 rows due to the addition of the on subclause, which instructs the server to join the customer and address tables by using the address_id column to traverse from one table to the other

	If a value exists for the address_id column in one table but not the other, then the join fails for the rows containing that value, and those rows are excluded from the result set. 

	This type of join is known as an inner join, and it is the most commonly used type of join

 	SELECT c.first_name, c.last_name, a.address
    FROM customer c INNER JOIN address a
    ON c.address_id = a.address_id;

	If the names of the columns used to join the two tables are identical, which is true in the previous query, you can use the using subclause instead of the on subclause, as in:

	SELECT c.first_name, c.last_name, a.address
	FROM customer c INNER JOIN address a
	USING (address_id);


	The ANSI Join Syntax

		SELECT c.first_name, c.last_name, a.address
    	FROM customer c, address a
    	WHERE c.address_id = a.address_id;

    	SELECT c.first_name, c.last_name, a.address
    	FROM customer c, address a
    	WHERE c.address_id = a.address_id
    	AND a.postal_code = 52137;

    Recommended Practice To Write Query In Following Syntax:

    	SELECT c.first_name, c.last_name, a.address
    	FROM customer c INNER JOIN address a
    	ON c.address_id = a.address_id
    	WHERE a.postal_code = 52137;

		SELECT c.first_name, c.last_name, ct.city
    	FROM customer c
    	INNER JOIN address a
    	ON c.address_id = a.address_id
    	INNER JOIN city ct
    	ON a.city_id = ct.city_id;


		SELECT c.first_name, c.last_name, ct.city
		FROM customer c
		  INNER JOIN address a
		  ON c.address_id = a.address_id
		  INNER JOIN city ct
		  ON a.city_id = ct.city_id;

		SELECT c.first_name, c.last_name, ct.city
		FROM city ct
		  INNER JOIN address a
		  ON a.city_id = ct.city_id
		  INNER JOIN customer c
		  ON c.address_id = a.address_id;

		SELECT c.first_name, c.last_name, ct.city
		FROM address a
		  INNER JOIN city ct
		  ON a.city_id = ct.city_id
		  INNER JOIN customer c
		  ON c.address_id = a.address_id;


DOES JOIN ORDER MATTER?
_______________________________________________________________________

	If you are confused about why all three versions of the customer/address/city query yield the same results, keep in mind that SQL is a nonprocedural language, meaning that you describe what you want to retrieve and which database objects need to be involved, but it is up to the database server to determine how best to execute your query. Using statistics gathered from your database objects, the server must pick one of three tables as a starting point (the chosen table is thereafter known as the driving table) and then decide in which order to join the remaining tables. Therefore, the order in which tables appear in your from clause is not significant.

	If, however, you believe that the tables in your query should always be joined in a particular order, you can place the tables in the desired order and then specify the keyword straight_join in MySQL, request the force order option in SQL Server, or use either the ordered or the leading optimizer hint in Oracle Database. For example, to tell the MySQL server to use the city table as the driving table and to then join the address and customer tables, you could do the following:
 
	 	SELECT STRAIGHT_JOIN c.first_name, c.last_name, ct.city FROM city ct
		INNER JOIN address a
		ON a.city_id = ct.city_id INNER JOIN customer c
		ON c.address_id = a.address_id


Using Subqueries as Tables
_______________________________________________________________________

	SELECT c.first_name, c.last_name, addr.address, addr.city
	FROM customer c
	INNER JOIN
	(SELECT a.address_id, a.address, ct.city
	FROM address a
	INNER JOIN city ct
	ON a.city_id = ct.city_id
	WHERE a.district = 'California'
	) addr
	ON c.address_id = addr.address_id;

	SELECT a.address_id, a.address, ct.city
    FROM address a
    INNER JOIN city ct
    ON a.city_id = ct.city_id
    WHERE a.district = 'California';

Using the Same Table Twice

	If you are joining multiple tables, you might find that you need to join the same table more than once. In the sample database, for example, actors are related to the films in which they appeared via the film_actor table. If you want to find all of the films in which two specific actors appear, you could write a query such as this one, which joins the film table to the film_actor table to the actor table:
	
	This query returns all movies in which either Cate McQueen or Cuba Birch appeared

		SELECT f.title
	    FROM film f
	    INNER JOIN film_actor fa
	    ON f.film_id = fa.film_id
	    INNER JOIN actor a
	    ON fa.actor_id = a.actor_id
	    WHERE ((a.first_name = 'CATE' AND a.last_name = 'MCQUEEN')
	    OR (a.first_name = 'CUBA' AND a.last_name = 'BIRCH'));


	However, let’s say that you want to retrieve only those films in which both of these actors appeared

		SELECT f.title
	    FROM film f
	    INNER JOIN film_actor fa1
	    ON f.film_id = fa1.film_id
	    INNER JOIN actor a1
	    ON fa1.actor_id = a1.actor_id
	    INNER JOIN film_actor fa2
	    ON f.film_id = fa2.film_id
	    INNER JOIN actor a2
	    ON fa2.actor_id = a2.actor_id
	    WHERE (a1.first_name = 'CATE' AND a1.last_name = 'MCQUEEN')
	    AND (a2.first_name = 'CUBA' AND a2.last_name = 'BIRCH');

SELF JOIN

	Not only can you include the same table more than once in the same query, but you can actually join a table to itself. This might seem like a strange thing to do at first, but there are valid reasons for doing so. Some tables include a self-referencing foreign key, which means that it includes a column that points to the primary key within the same table. While the sample database doesn’t include such a relationship, let’s imagine that the film table includes the column prequel_film_id, which points to the film’s parent (e.g., the film Fiddler Lost II would use this column to point to the parent film Fiddler Lost). Here’s what the table would look like if we were to add this additional column:

	Using a self-join, you can write a query that lists every film that has a prequel, along with the prequel’s title:

		SELECT f.title, f_prnt.title prequel
		FROM film f
		INNER JOIN film f_prnt
		ON f_prnt.film_id = f.prequel_film_id
		WHERE f.prequel_film_id IS NOT NULL;

UNION OPERATOR

	The union and union all operators allow you to combine multiple data sets. 

	The difference between the two is that union sorts the combined set and removes duplicates, whereas union all does not.

	SELECT 'CUST' typ, c.first_name, c.last_name
	FROM customer c
    UNION ALL
    SELECT 'ACTR' typ, a.first_name, a.last_name
    FROM actor a;

	SELECT c.first_name, c.last_name
	FROM customer c
	WHERE c.first_name LIKE 'J%' AND c.last_name LIKE 'D%' 
	UNION
	SELECT a.first_name, a.last_name
	FROM actor a
	WHERE a.first_name LIKE 'J%' AND a.last_name LIKE 'D%';


INTERSECT OPERATOR

	The ANSI SQL specification includes the intersect operator for performing intersections.

	Unfortunately, version 8.0 of MySQL does not implement the intersect operator. 

	SELECT c.first_name, c.last_name
	FROM customer c
	WHERE c.first_name LIKE 'D%' AND c.last_name LIKE 'T%' 
	INTERSECT
	SELECT a.first_name, a.last_name
	FROM actor a
	WHERE a.first_name LIKE 'D%' AND a.last_name LIKE 'T%';

Sorting Compound Query Results

	If you want the results of your compound query to be sorted, you can add an order by clause after the last query.
	
	When specifying column names in the order by clause, you will need to choose from the column names in the first query of the compound query.

	SELECT a.first_name fname, a.last_name lname 
	FROM actor a
	WHERE a.first_name LIKE 'J%' AND a.last_name LIKE 'D%'
	UNION ALL
	SELECT c.first_name, c.last_name
	FROM customer c
	WHERE c.first_name LIKE 'J%' AND c.last_name LIKE 'D%'
	ORDER BY lname, fname;

	SELECT a.first_name fname, a.last_name lname
    FROM actor a
    WHERE a.first_name LIKE 'J%' AND a.last_name LIKE 'D%'
    UNION ALL
    SELECT c.first_name, c.last_name
    FROM customer c
    WHERE c.first_name LIKE 'J%' AND c.last_name LIKE 'D%'
	ORDER BY last_name, first_name;

Set Operation Precedence
	If your compound query contains more than two queries using different set operators, you need to think about the order in which to place the queries in your compound statement to achieve the desired results. 
	Consider the following three-query compound statement:

	SELECT a.first_name, a.last_name
	FROM actor a
	WHERE a.first_name LIKE 'J%' AND a.last_name LIKE 'D%'
	UNION ALL
	SELECT a.first_name, a.last_name
	FROM actor a
	WHERE a.first_name LIKE 'M%' AND a.last_name LIKE 'T%'
	UNION
	SELECT c.first_name, c.last_name
	FROM customer c
	WHERE c.first_name LIKE 'J%' AND c.last_name LIKE 'D%';

 
 	In general, compound queries containing three or more queries are evaluated in order from top to bottom, but with the following caveats:
	
		The ANSI SQL specification calls for the intersect operator to have precedence over the other set operators.
	
		You may dictate the order in which queries are combined by enclosing multiple queries in parentheses.


	SELECT a.first_name, a.last_name
	FROM actor a
	WHERE a.first_name LIKE 'J%' AND a.last_name LIKE 'D%' UNION
	(SELECT a.first_name, a.last_name
	 FROM actor a
	 WHERE a.first_name LIKE 'M%' AND a.last_name LIKE 'T%'
	 UNION ALL
	 SELECT c.first_name, c.last_name
	 FROM customer c
	 WHERE c.first_name LIKE 'J%' AND c.last_name LIKE 'D%'
	)


HOME WORK
	Working with String Data
	Working with Numeric Data
	Working with Temporal Data


Grouping and Aggregates
==================================


GROUP BY Clause
======================
	SELECT customer_id FROM rental;

	SELECT customer_id
    FROM rental
    GROUP BY customer_id;

	To see how many films each customer rented, you can use 
	An aggregate function in the select clause to count the number of rows in each group:

	SELECT customer_id, count(*)
	FROM rental
	GROUP BY customer_id;

	SELECT customer_id, count(*)
	FROM rental
	GROUP BY customer_id
	HAVING count(*) >= 40;

Aggregate Functions
	
	max()		Returns the maximum value within a set
	min()		Returns the minimum value within a set
	avg()		Returns the average value across a set
	sum()		Returns the sum of the values across a set
	count()		Returns the number of values in a set


	SELECT MAX(amount) max_amt,
    MIN(amount) min_amt,
    AVG(amount) avg_amt,
    SUM(amount) tot_amt,
    COUNT(*) num_payments
    FROM payment;

	In above example, every value returned by the query is generated by an aggregate function. Since there is no group by clause, there is a single, implicit group (all rows in the payment table).

	SELECT customer_id,
	MAX(amount) max_amt,
    MIN(amount) min_amt,
    AVG(amount) avg_amt,
    SUM(amount) tot_amt,
    COUNT(*) num_payments
    FROM payment
    GROUP BY customer_id;

Counting Distinct Values

	When using the count() function to determine the number of members in each group, you have your choice of counting all members in the group or counting only the distinct values for a column across all members of the group.

	SELECT COUNT(customer_id) num_rows,
	COUNT(DISTINCT customer_id) num_customers
	FROM payment;

	SELECT MAX(datediff(return_date,rental_date))
    FROM rental;


How Nulls Are Handled
	
	When performing aggregations, or, indeed, any type of numeric calculation, you should always consider how null values might affect the outcome of your calculation.

		CREATE TABLE number_tbl (val SMALLINT);

		INSERT INTO number_tbl VALUES (1);
		INSERT INTO number_tbl VALUES (3);
		INSERT INTO number_tbl VALUES (5);

		SELECT COUNT(*) num_rows,
	    COUNT(val) num_vals,
	    SUM(val) total,
		MAX(val) max_val,
	    AVG(val) avg_val
	    FROM number_tbl;

		INSERT INTO number_tbl VALUES (NULL);

	Even with the addition of the null value to the table, the sum(), max(), and avg() functions all return the same values, indicating that they ignore any null values encountered. The count(*) function now returns the value 4, which is valid since the number_tbl table contains four rows, 

	While the count(val) function still returns the value 3. The difference is that count(*) counts the number of rows, whereas count(val) counts the number of values contained in the val column and ignores any null values encountered.

Single-Column Grouping

	SELECT actor_id, count(*)
	FROM film_actor
    GROUP BY actor_id;

Multicolumn Grouping

	SELECT fa.actor_id, f.rating, count(*)
    FROM film_actor fa
    INNER JOIN film f
    ON fa.film_id = f.film_id
    GROUP BY fa.actor_id, f.rating
    ORDER BY 1,2;

Grouping via Expressions

	SELECT extract(YEAR FROM rental_date) year,
    COUNT(*) how_many
    FROM rental
    GROUP BY extract(YEAR FROM rental_date);

What Is a Subquery?
	A subquery is a query contained within another SQL statement (which I refer to as the containing statement for the rest of this discussion). 

	A subquery is always enclosed within parentheses, and it is usually executed prior to the containing statement. Like any query, a subquery returns a result set that may consist of:

		A single row with a single column 
		Multiple rows with a single column 
		Multiple rows having multiple columns

	When the containing statement has finished executing, the data returned by any subqueries is discarded, making a subquery act like a temporary table with statement scope (meaning that the server frees up any memory allocated to the subquery results after the SQL statement has finished execution).


		SELECT customer_id, first_name, last_name
		FROM customer
		WHERE customer_id = (SELECT MAX(customer_id) FROM customer);

Subquery Types
	Along with the differences noted previously regarding the type of result set returned by a subquery (single row/column, single row/multicolumn, or multiple columns)

	Some subqueries are completely self-contained 
		(called noncorrelated subqueries), 
	While others reference columns from the containing statement 
		(called correlated subqueries). 

Noncorrelated Subqueries

	It may be executed alone and does not reference anything from the containing statement. 

	Most subqueries that you encounter will be of this type unless you are writing update or delete statements, which frequently make use of correlated subqueries. 

	Along with being noncorrelated, also returns a result set containing a single row and column. This type of subquery is known as a scalar subquery and can appear on either side of a condition using the usual operators (=, <>, <, >, <=, >=).

	SELECT city_id, city
    FROM city
    WHERE country_id <> (SELECT country_id FROM country WHERE country = 'India');

	If you use a subquery in an equality condition but the subquery returns more than one row, you will receive an error.

	SELECT city_id, city
    FROM city
    WHERE country_id <> (SELECT country_id FROM country WHERE country <> 'India');

Multiple-Row, Single-Column Subqueries

	THE IN AND NOT IN OPERATORS
		While you can’t equate a single value to a set of values, you can check to see whether a single value can be found within a set of values. The next example, while it doesn’t use a subquery, demonstrates how to build a condition that uses the in operator to search for a value within a set of values:

	SELECT country_id
    FROM country
    WHERE country IN ('Canada','Mexico');

	SELECT city_id, city
    FROM city
    WHERE country_id IN
    (SELECT country_id
    FROM country
    WHERE country IN ('Canada','Mexico'));

	SELECT city_id, city
    FROM city
    WHERE country_id NOT IN
    (SELECT country_id
    FROM country
    WHERE country IN ('Canada','Mexico'));

THE ALL OPERATOR
	While the in operator is used to see whether an expression can be found within a set of expressions, the all operator allows you to make comparisons between a single value and every value in a set.

	To build such a condition, you will need to use one of the comparison operators (=, <>, <, >, etc.) in conjunction with the all operator

	SELECT first_name, last_name
    FROM customer
	WHERE customer_id <> ALL
	(SELECT customer_id
    FROM payment
    WHERE amount = 0);

VERY IMPORTANT NOTE
	When using not in or <> all to compare a value to a set of values, you must be careful to ensure that the set of values does not contain a null value, because the server equates the value on the lefthand side of the expression to each member of the set, and any attempt to equate a value to null yields unknown. Thus, the following query returns an empty set:

	SELECT first_name, last_name
	FROM customer
	WHERE customer_id NOT IN (122, 452, NULL); 
	Empty set (0.00 sec)

	SELECT customer_id, count(*)
    FROM rental
	GROUP BY customer_id 
	HAVING count(*) > ALL 
	(SELECT count(*)
    FROM rental r
    INNER JOIN customer c
    ON r.customer_id = c.customer_id
    INNER JOIN address a
    ON c.address_id = a.address_id
    INNER JOIN city ct
    ON a.city_id = ct.city_id
    INNER JOIN country co
    ON ct.country_id = co.country_id
    WHERE co.country IN ('United States','Mexico','Canada')
    GROUP BY r.customer_id
    );
	
	The subquery in this example returns the total number of film rentals for all customers in North America, and the containing query returns all customers whose total number of film rentals exceeds any of the North American customers.

THE ANY OPERATOR

	Like the all operator, the any operator allows a value to be compared to the members of a set of values; 

	Unlike all, however, a condition using the any operator evaluates to true as soon as a single comparison is favorable. 

	This example will find all customers whose total film rental payments exceed the total payments for all customers in Bolivia, Paraguay, or Chile:

	SELECT customer_id, sum(amount)
    FROM payment
	GROUP BY customer_id
	HAVING sum(amount) > ANY 
	(SELECT sum(p.amount)
    FROM payment p
    INNER JOIN customer c
    ON p.customer_id = c.customer_id
    INNER JOIN address a
    ON c.address_id = a.address_id
    INNER JOIN city ct
    ON a.city_id = ct.city_id
    INNER JOIN country co
    ON ct.country_id = co.country_id
    WHERE co.country IN ('Bolivia','Paraguay','Chile')
    GROUP BY co.country
    );

	The subquery returns the total film rental fees for all customers in Bolivia, Paraguay, and Chile, and the containing query returns all customers who outspent at least one of these three countries


