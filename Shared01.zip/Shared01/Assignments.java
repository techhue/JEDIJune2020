
DAY 01
__________________________________________________________________

	Reading and Practice Assignment
	______________________________________________________________
		Reference Book
			Linux Pocket Guide, Orielly Publication
				Pages 11 To 29
				Pages 37 to 70

DAY 02
__________________________________________________________________
	Reading and Practice Assignment
	______________________________________________________________
		Reference Book
			Linux Pocket Guide, Orielly Publication
				Pages 71 to 95
				Pages 104 to 114

		Reference Book
			Linux Pocket Guide, Orielly Publication
				Pages 71 to 95
				Pages 104 to 114

	


